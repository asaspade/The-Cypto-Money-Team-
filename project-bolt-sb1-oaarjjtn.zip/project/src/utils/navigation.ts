export const routes = {
  home: '/',
  tokenDetail: (id: string) => `/token/${id}`,
  createToken: '/token/launch',
  howItWorks: '/how-it-works',
  getKyc: '/get-kyc',
  about: '/about',
  swapper: '/swapper',
  premiumTokens: '/premium-tokens'
} as const;
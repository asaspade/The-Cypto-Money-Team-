import { tokenImages } from './tokenData';

export const tokenData = {
  id: '1',
  name: 'MetaVerse Token',
  symbol: 'MVT',
  chainId: 'vitruveo',
  address: '0x8BEFf5EC6A15F499EfA446b1eb9F1c74dcFe9495',
  price: '0.05 USDT',
  totalRaised: '750,000 USDT',
  participants: 1250,
  timeLeft: '2d 5h',
  current: 750000,
  target: 1000000,
  percentageRaised: 75,
  minContribution: '100 USDT',
  maxContribution: '10,000 USDT',
  description: 'MetaVerse Token (MVT) is revolutionizing the virtual world experience by creating an interconnected ecosystem of digital assets and experiences. Built on cutting-edge blockchain technology, MVT enables seamless transactions and ownership verification in the metaverse.',
  website: 'https://metaverse-token.io',
  twitter: 'https://twitter.com/metaversetoken',
  discord: 'https://discord.gg/metaversetoken',
  imageUrl: tokenImages.MVT,
  marketCap: '$25,000,000',
  totalSupply: '100,000,000 MVT',
  network: 'Vitruveo',
  blastOffProgress: 65,
  estimatedLaunch: 'March 25, 2024',
  transactions: [
    {
      id: '1',
      type: 'buy',
      amount: '25,000 MVT',
      price: '0.05 USDT',
      date: '2024-03-15 14:30',
      account: '0x1234567890abcdef1234567890abcdef12345678'
    },
    {
      id: '2',
      type: 'sell',
      amount: '10,000 MVT',
      price: '0.048 USDT',
      date: '2024-03-15 14:25',
      account: '0xabcdef1234567890abcdef1234567890abcdef12'
    },
    {
      id: '3',
      type: 'buy',
      amount: '50,000 MVT',
      price: '0.049 USDT',
      date: '2024-03-15 14:20',
      account: '0x7890abcdef1234567890abcdef1234567890abcd'
    }
  ],
  holderDistribution: {
    totalHolders: 15234,
    distribution: [
      { range: '100,000+ MVT', percentage: 15, count: 52 },
      { range: '50,000-100,000 MVT', percentage: 25, count: 156 },
      { range: '10,000-50,000 MVT', percentage: 35, count: 892 },
      { range: '1,000-10,000 MVT', percentage: 20, count: 14134 }
    ]
  }
};

export const featuredTokens = [
  {
    id: '1',
    name: 'MetaVerse Token',
    symbol: 'MVT',
    chainId: 'vitruveo',
    price: '0.05 USDT',
    progress: 75,
    timeLeft: '2d 5h',
    participants: 1250,
    raised: '750K USDT',
    imageUrl: tokenImages.MVT
  },
  {
    id: '4',
    name: 'PulseX',
    symbol: 'PLSX',
    chainId: 'pulsechain',
    price: '0.0001 PLS',
    progress: 85,
    timeLeft: '1d 12h',
    participants: 3200,
    raised: '1.2M PLS',
    imageUrl: tokenImages.PLSX
  },
  {
    id: '5',
    name: 'Pulse Token',
    symbol: 'PULSE',
    chainId: 'pulsechain',
    price: '0.0002 PLS',
    progress: 65,
    timeLeft: '3d 8h',
    participants: 2800,
    raised: '950K PLS',
    imageUrl: tokenImages.PULSE
  }
] as const;
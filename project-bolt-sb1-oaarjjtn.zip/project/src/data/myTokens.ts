import { tokenImages } from './tokenData';

export const myTokens = [
  {
    id: '2',
    name: 'DeFi Protocol',
    symbol: 'DFP',
    chainId: 'vitruveo',
    price: '0.08 USDT',
    progress: 45,
    timeLeft: '5d 12h',
    participants: 890,
    raised: '450K USDT',
    imageUrl: tokenImages.DFP
  },
  {
    id: '6',
    name: 'PulseChain DEX',
    symbol: 'PDEX',
    chainId: 'pulsechain',
    price: '0.0003 PLS',
    progress: 55,
    timeLeft: '4d 8h',
    participants: 1500,
    raised: '800K PLS',
    imageUrl: tokenImages.PLSX
  }
];
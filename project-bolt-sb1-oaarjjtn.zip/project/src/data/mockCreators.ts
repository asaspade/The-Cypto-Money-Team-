export const mockCreators = [
  {
    address: '0x1234567890abcdef1234567890abcdef12345678',
    name: 'CryptoWhale',
    isVerified: true,
    tokensCreated: 15,
    totalValue: 2500000,
    chains: ['vitruveo', 'pulsechain', 'bnb']
  },
  {
    address: '0xabcdef1234567890abcdef1234567890abcdef12',
    name: 'TokenMaster',
    isVerified: true,
    tokensCreated: 12,
    totalValue: 1800000,
    chains: ['vitruveo', 'pulsechain']
  },
  {
    address: '0x7890abcdef1234567890abcdef1234567890abcd',
    name: 'BlockchainBuilder',
    isVerified: true,
    tokensCreated: 8,
    totalValue: 1200000,
    chains: ['vitruveo', 'bnb']
  },
  {
    address: '0x4567890abcdef1234567890abcdef1234567890',
    tokensCreated: 5,
    totalValue: 800000,
    chains: ['pulsechain']
  },
  {
    address: '0xdef1234567890abcdef1234567890abcdef12345',
    tokensCreated: 3,
    totalValue: 500000,
    chains: ['vitruveo']
  }
];
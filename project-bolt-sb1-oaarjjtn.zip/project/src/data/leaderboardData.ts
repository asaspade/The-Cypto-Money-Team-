export const volumeLeaders = [
  { name: 'MetaVerse Token', symbol: 'MVT', value: '$2.5M', change: '+12%', isPositive: true },
  { name: 'DeFi Protocol', symbol: 'DFP', value: '$1.8M', change: '+8%', isPositive: true },
  { name: 'GameFi Token', symbol: 'GFT', value: '$1.2M', change: '-3%', isPositive: false },
];

export const topGainers = [
  { name: 'AI Network', symbol: 'AIN', value: '$0.85', change: '+45%', isPositive: true },
  { name: 'Solar Energy', symbol: 'SOLAR', value: '$1.20', change: '+32%', isPositive: true },
  { name: 'NFT World', symbol: 'NFTW', value: '$2.15', change: '+28%', isPositive: true },
];

export const topDeclining = [
  { name: 'Old Chain', symbol: 'OLD', value: '$0.45', change: '-15%', isPositive: false },
  { name: 'Meme Token', symbol: 'MEME', value: '$0.02', change: '-12%', isPositive: false },
  { name: 'Legacy Protocol', symbol: 'LGC', value: '$1.05', change: '-8%', isPositive: false },
];
// Token images from Unsplash
export const tokenImages = {
  MVT: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=200&h=200',
  DFP: 'https://images.unsplash.com/photo-1639762681057-408e52192e55?auto=format&fit=crop&w=200&h=200',
  GFT: 'https://images.unsplash.com/photo-1639762681345-07c6dc58dfb1?auto=format&fit=crop&w=200&h=200',
  VTRU: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=200&h=200',
  PLSX: 'https://images.unsplash.com/photo-1639762681057-408e52192e55?auto=format&fit=crop&w=200&h=200',
  PULSE: 'https://images.unsplash.com/photo-1639762681345-07c6dc58dfb1?auto=format&fit=crop&w=200&h=200'
};
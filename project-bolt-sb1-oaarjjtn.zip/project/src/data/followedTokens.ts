import { tokenImages } from './tokenData';

export const followedTokens = [
  {
    id: '1',
    name: 'MetaVerse Token',
    symbol: 'MVT',
    chainId: 'vitruveo',
    price: '0.05 USDT',
    progress: 75,
    timeLeft: '2d 5h',
    participants: 1250,
    raised: '750K USDT',
    imageUrl: tokenImages.MVT
  },
  {
    id: '4',
    name: 'PulseX',
    symbol: 'PLSX',
    chainId: 'pulsechain',
    price: '0.0001 PLS',
    progress: 85,
    timeLeft: '1d 12h',
    participants: 3200,
    raised: '1.2M PLS',
    imageUrl: tokenImages.PLSX
  }
];
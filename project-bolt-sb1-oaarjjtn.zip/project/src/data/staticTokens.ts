import { tokenImages } from './tokenData';

export const staticTokens = [
  {
    id: '3',
    name: 'GameFi Token',
    symbol: 'GFT',
    chainId: 'vitruveo',
    price: '0.03 USDT',
    progress: 90,
    timeLeft: '1d 8h',
    participants: 2100,
    raised: '900K USDT',
    imageUrl: tokenImages.GFT
  },
  {
    id: '7',
    name: 'PulseChain Gaming',
    symbol: 'PGAME',
    chainId: 'pulsechain',
    price: '0.0005 PLS',
    progress: 70,
    timeLeft: '3d 16h',
    participants: 1800,
    raised: '950K PLS',
    imageUrl: tokenImages.PULSE
  }
];
import { tokenImages } from './tokenData';

export const liveTokens = [
  {
    id: '4',
    name: 'Vitruveo',
    symbol: 'VTRU',
    chainId: 'vitruveo',
    price: 'View on CoinGecko',
    progress: 100,
    timeLeft: 'Live',
    participants: 5000,
    raised: '2.5M USDT',
    imageUrl: tokenImages.VTRU
  },
  {
    id: '8',
    name: 'PulseX',
    symbol: 'PLSX',
    chainId: 'pulsechain',
    price: 'View on CoinGecko',
    progress: 100,
    timeLeft: 'Live',
    participants: 8500,
    raised: '5.2M PLS',
    imageUrl: tokenImages.PLSX
  },
  {
    id: '9',
    name: 'Pulse',
    symbol: 'PLS',
    chainId: 'pulsechain',
    price: 'View on CoinGecko',
    progress: 100,
    timeLeft: 'Live',
    participants: 12000,
    raised: '8.1M PLS',
    imageUrl: tokenImages.PULSE
  }
];
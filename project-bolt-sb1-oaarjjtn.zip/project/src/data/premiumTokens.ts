export const premiumTokens = [
  {
    id: 'tcmt',
    name: 'The Crypto Money Token',
    symbol: 'TCMT',
    price: '$0.0458',
    change: '+12.5%',
    isPositive: true,
    marketCap: '$45.8M',
    volume24h: '$2.3M',
    holders: 15234,
    description: 'Leading DeFi protocol revolutionizing decentralized finance',
    website: 'https://example.com',
    twitter: 'https://twitter.com/example',
    imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=100&h=100'
  },
  {
    id: 'pepe',
    name: 'Pepe',
    symbol: 'PEPE',
    price: '$0.00000123',
    change: '+8.2%',
    isPositive: true,
    marketCap: '$12.3M',
    volume24h: '$890K',
    holders: 8945,
    description: 'Community-driven meme token with strong social engagement',
    website: 'https://example.com',
    twitter: 'https://twitter.com/example',
    imageUrl: 'https://images.unsplash.com/photo-1639762681057-408e52192e55?auto=format&fit=crop&w=100&h=100'
  },
  {
    id: 'brat',
    name: 'Brother Token',
    symbol: 'BRAT',
    price: '$0.0789',
    change: '-2.4%',
    isPositive: false,
    marketCap: '$23.4M',
    volume24h: '$1.2M',
    holders: 12567,
    description: 'Next-generation gaming platform token',
    website: 'https://example.com',
    twitter: 'https://twitter.com/example',
    imageUrl: 'https://images.unsplash.com/photo-1639762681345-07c6dc58dfb1?auto=format&fit=crop&w=100&h=100'
  }
];
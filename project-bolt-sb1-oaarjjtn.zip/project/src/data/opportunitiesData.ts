export const opportunities = [
  {
    id: '1',
    title: 'MVT Staking Pool',
    description: 'Earn rewards by staking MVT tokens in the official pool',
    apy: '120%',
    lockPeriod: '90 days',
    participants: 450,
    totalStaked: '2.5M MVT'
  },
  {
    id: '2',
    title: 'DFP Liquidity Mining',
    description: 'Provide liquidity to earn DFP tokens and trading fees',
    apy: '85%',
    lockPeriod: '30 days',
    participants: 280,
    totalStaked: '1.8M DFP'
  }
];
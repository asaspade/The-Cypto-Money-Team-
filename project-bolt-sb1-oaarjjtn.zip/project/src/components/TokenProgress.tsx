import React from 'react';

interface TokenProgressProps {
  current: number;
  target: number;
  percentageRaised: number;
}

export default function TokenProgress({ current, target, percentageRaised }: TokenProgressProps) {
  return (
    <div className="stats-card">
      <div className="flex justify-between mb-2">
        <span className="text-gray-400">Progress</span>
        <span className="text-primary-400">{percentageRaised}%</span>
      </div>
      
      <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
        <div 
          className="bg-gradient-to-r from-primary-500 to-primary-600 h-2 rounded-full transition-all duration-500" 
          style={{ width: `${percentageRaised}%` }}
        />
      </div>
      
      <div className="flex justify-between text-sm">
        <div>
          <div className="text-gray-400">Current</div>
          <div className="font-bold text-primary-400">{current} USDT</div>
        </div>
        <div className="text-right">
          <div className="text-gray-400">Target</div>
          <div className="font-bold text-primary-400">{target} USDT</div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { ArrowUpRight, ArrowDownRight, ExternalLink } from 'lucide-react';

interface Transaction {
  id: string;
  type: 'buy' | 'sell';
  amount: string;
  price: string;
  date: string;
  account: string;
}

interface TokenTransactionsProps {
  transactions: Transaction[];
}

export default function TokenTransactions({ transactions }: TokenTransactionsProps) {
  const shortenAddress = (addr: string) => `${addr.slice(0, 6)}...${addr.slice(-4)}`;

  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
        Recent Transactions
      </h3>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-gray-400 border-b border-primary-500/10">
              <th className="pb-4">Type</th>
              <th className="pb-4">Account</th>
              <th className="pb-4">Amount</th>
              <th className="pb-4">Price</th>
              <th className="pb-4">Date</th>
              <th className="pb-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-primary-500/10">
            {transactions.map((tx) => (
              <tr key={tx.id} className="hover:bg-primary-500/5">
                <td className="py-4">
                  <div className="flex items-center gap-2">
                    {tx.type === 'buy' ? (
                      <ArrowUpRight className="w-4 h-4 text-green-500" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4 text-red-500" />
                    )}
                    <span className={tx.type === 'buy' ? 'text-green-500' : 'text-red-500'}>
                      {tx.type.toUpperCase()}
                    </span>
                  </div>
                </td>
                <td className="py-4 font-mono text-primary-400">{shortenAddress(tx.account)}</td>
                <td className="py-4 text-primary-400">{tx.amount}</td>
                <td className="py-4 text-primary-400">{tx.price}</td>
                <td className="py-4 text-gray-400">{tx.date}</td>
                <td className="py-4">
                  <button className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors">
                    <ExternalLink className="w-4 h-4 text-primary-400" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
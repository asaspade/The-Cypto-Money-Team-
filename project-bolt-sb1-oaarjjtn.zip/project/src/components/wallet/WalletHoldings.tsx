import React from 'react';
import { Wallet, ExternalLink } from 'lucide-react';
import BlockchainBadge from '../blockchain/BlockchainBadge';
import { useWalletHoldings } from '../../hooks/useWalletHoldings';

export default function WalletHoldings() {
  const { holdings, totalValue, isLoading } = useWalletHoldings();

  if (isLoading) {
    return (
      <div className="stats-card animate-pulse">
        <div className="h-8 w-1/3 bg-gray-800 rounded mb-6" />
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-800 rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="stats-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Wallet className="w-6 h-6 text-primary-500" />
          <h3 className="text-xl font-bold">Wallet Holdings</h3>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-400">Total Value</div>
          <div className="text-lg font-bold text-primary-400">
            ${totalValue.toLocaleString()}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {holdings.map((token) => (
          <div key={token.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-4">
              {token.imageUrl ? (
                <img 
                  src={token.imageUrl} 
                  alt={token.name}
                  className="w-10 h-10 rounded-lg"
                />
              ) : (
                <div className="w-10 h-10 rounded-lg bg-primary-500/20 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary-400">
                    {token.symbol[0]}
                  </span>
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{token.name}</span>
                  <BlockchainBadge chainId={token.chainId} showName={false} />
                </div>
                <div className="text-sm text-gray-400">
                  {token.balance} {token.symbol}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-medium">${token.value.toLocaleString()}</div>
              <div className={`text-sm ${token.priceChange24h >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {token.priceChange24h >= 0 ? '+' : ''}{token.priceChange24h}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
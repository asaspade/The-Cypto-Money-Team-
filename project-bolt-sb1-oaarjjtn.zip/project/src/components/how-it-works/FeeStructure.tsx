import React from 'react';
import { DollarSign, Percent } from 'lucide-react';
import { PLATFORM_FEES } from '../../config/fees';

export default function FeeStructure() {
  return (
    <div className="grid md:grid-cols-2 gap-8 mb-16">
      <div className="stats-card">
        <div className="flex items-center gap-3 mb-4">
          <DollarSign className="w-6 h-6 text-primary-500" />
          <h3 className="text-xl font-bold">Listing Fee</h3>
        </div>
        <div className="space-y-4">
          <p className="text-gray-400">
            A one-time fee of ${PLATFORM_FEES.LISTING_FEE} USDC (BNB) is required to list your token on our platform.
          </p>
          <div className="bg-primary-500/10 p-4 rounded-lg border border-primary-500/20">
            <div className="text-sm text-gray-400 mb-2">Payment Address:</div>
            <p className="text-sm font-mono break-all text-primary-400">
              {PLATFORM_FEES.FEE_WALLET}
            </p>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3 mb-4">
          <Percent className="w-6 h-6 text-primary-500" />
          <h3 className="text-xl font-bold">Transaction Fee</h3>
        </div>
        <p className="text-gray-400">
          A {PLATFORM_FEES.TRANSACTION_FEE_PERCENT}% fee applies to all token buy and sell transactions. 
          This fee helps maintain the platform and supports ongoing development.
        </p>
      </div>
    </div>
  );
}
import React from 'react';
import { Rocket, Shield, DollarSign, CheckCircle } from 'lucide-react';

const instructions = [
  {
    icon: Shield,
    title: 'Prepare Requirements',
    steps: [
      'Complete KYC verification',
      'Prepare token contract code',
      'Get smart contract audit (recommended)',
      'Prepare project documentation'
    ]
  },
  {
    icon: DollarSign,
    title: 'Pay Listing Fee',
    steps: [
      'Send $25 USDC (BNB) to the platform wallet',
      'Keep transaction hash for verification',
      'Wait for payment confirmation'
    ]
  },
  {
    icon: Rocket,
    title: 'Configure Launch',
    steps: [
      'Set token distribution parameters',
      'Configure presale details',
      'Set vesting schedules',
      'Define launch timeline'
    ]
  },
  {
    icon: CheckCircle,
    title: 'Launch & Manage',
    steps: [
      'Submit for final review',
      'Monitor launch progress',
      'Engage with participants',
      'Track performance metrics'
    ]
  }
];

export default function LaunchInstructions() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-center mb-8">
        Launch Instructions
      </h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        {instructions.map((section, index) => {
          const Icon = section.icon;
          return (
            <div key={index} className="stats-card">
              <div className="flex items-center gap-3 mb-4">
                <Icon className="w-6 h-6 text-primary-500" />
                <h3 className="text-xl font-bold">{section.title}</h3>
              </div>
              <ul className="space-y-3">
                {section.steps.map((step, stepIndex) => (
                  <li key={stepIndex} className="flex items-center gap-2 text-gray-400">
                    <span className="w-5 h-5 flex items-center justify-center rounded-full bg-primary-500/20 text-primary-500 text-sm">
                      {stepIndex + 1}
                    </span>
                    {step}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}
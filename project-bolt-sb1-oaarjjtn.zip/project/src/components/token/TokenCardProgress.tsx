import React from 'react';
import { Rocket } from 'lucide-react';

interface TokenCardProgressProps {
  progress: number;
  raised: string;
}

export default function TokenCardProgress({ progress, raised }: TokenCardProgressProps) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <Rocket className="w-4 h-4 text-primary-400" />
          <span className="text-gray-400">Progress</span>
        </div>
        <span className="font-medium">{raised}</span>
      </div>
      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-primary-500 to-primary-600 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="text-right text-sm text-primary-400 font-medium">
        {progress}%
      </div>
    </div>
  );
}
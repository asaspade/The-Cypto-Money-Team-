import React from 'react';
import { DollarSign, Users, PieChart, Coins } from 'lucide-react';

interface TokenCardStatsProps {
  price: string;
  participants: number;
  marketCap: string;
  totalSupply: string;
}

export default function TokenCardStats({ 
  price, 
  participants, 
  marketCap, 
  totalSupply 
}: TokenCardStatsProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-primary-400" />
          <div>
            <div className="text-sm text-gray-400">Price</div>
            <div className="font-medium">{price}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-primary-400" />
          <div>
            <div className="text-sm text-gray-400">Participants</div>
            <div className="font-medium">{participants}</div>
          </div>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <PieChart className="w-4 h-4 text-primary-400" />
          <div>
            <div className="text-sm text-gray-400">Market Cap</div>
            <div className="font-medium">{marketCap}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Coins className="w-4 h-4 text-primary-400" />
          <div>
            <div className="text-sm text-gray-400">Total Supply</div>
            <div className="font-medium">{totalSupply}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Clock } from 'lucide-react';

interface TokenCardTimerProps {
  timeLeft: string;
}

export default function TokenCardTimer({ timeLeft }: TokenCardTimerProps) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <Clock className="w-4 h-4 text-primary-400" />
      <span className="text-gray-400">Time Left:</span>
      <span className="font-medium text-white">{timeLeft}</span>
    </div>
  );
}
import React, { useState } from 'react';
import { AlertCircle } from 'lucide-react';
import Button from './common/Button';
import { useWallet } from '../contexts/WalletContext';

interface TokenActionsProps {
  minContribution: string;
  maxContribution: string;
}

export default function TokenActions({ minContribution, maxContribution }: TokenActionsProps) {
  const [amount, setAmount] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const { account } = useWallet();

  const handleParticipate = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsLoading(false);
  };

  const isValidAmount = Number(amount) >= Number(minContribution.split(' ')[0]) && 
                       Number(amount) <= Number(maxContribution.split(' ')[0]);

  return (
    <div className="stats-card">
      <div className="flex justify-between mb-4">
        <div>
          <div className="text-gray-400 mb-1">Min. Contribution</div>
          <div className="font-bold text-primary-400">{minContribution}</div>
        </div>
        <div className="text-right">
          <div className="text-gray-400 mb-1">Max. Contribution</div>
          <div className="font-bold text-primary-400">{maxContribution}</div>
        </div>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-gray-400 mb-2">Amount (USDT)</label>
          <input
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>
        
        {!account ? (
          <Button variant="primary" fullWidth>
            Connect Wallet
          </Button>
        ) : (
          <Button
            variant="primary"
            fullWidth
            isLoading={isLoading}
            disabled={!isValidAmount}
            onClick={handleParticipate}
          >
            {isLoading ? 'Processing...' : 'Participate'}
          </Button>
        )}
        
        <div className="flex items-start gap-2 text-sm text-gray-400">
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-primary-500" />
          <p>Make sure you have enough USDT in your wallet before participating.</p>
        </div>
      </div>
    </div>
  );
}
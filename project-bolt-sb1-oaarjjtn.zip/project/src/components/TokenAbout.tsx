import React from 'react';
import { Info, Globe, Twitter, MessageSquare } from 'lucide-react';

interface TokenAboutProps {
  description: string;
  website?: string;
  twitter?: string;
  discord?: string;
  imageUrl?: string;
}

export default function TokenAbout({ description, website, twitter, discord, imageUrl }: TokenAboutProps) {
  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Info className="w-5 h-5 text-primary-500" />
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          About Project
        </span>
      </h3>
      
      <div className="flex gap-6">
        {imageUrl && (
          <div className="flex-shrink-0">
            <img 
              src={imageUrl} 
              alt="Token Logo" 
              className="w-24 h-24 rounded-xl object-cover border border-primary-500/20"
            />
          </div>
        )}
        
        <div className="flex-1">
          <p className="text-gray-400 mb-6 leading-relaxed">
            {description}
          </p>
          
          <div className="flex flex-wrap gap-4">
            {website && (
              <a 
                href={website}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-primary-500 transition-colors"
              >
                <Globe className="w-5 h-5" />
                Website
              </a>
            )}
            {twitter && (
              <a 
                href={twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-primary-500 transition-colors"
              >
                <Twitter className="w-5 h-5" />
                Twitter
              </a>
            )}
            {discord && (
              <a 
                href={discord}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-primary-500 transition-colors"
              >
                <MessageSquare className="w-5 h-5" />
                Discord
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
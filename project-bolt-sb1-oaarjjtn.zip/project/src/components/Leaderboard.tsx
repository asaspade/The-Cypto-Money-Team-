import React from 'react';
import { Trophy, TrendingUp, Users } from 'lucide-react';

const leaderboardData = [
  { rank: 1, name: 'MetaVerse Token', gain: '+245%', holders: '12.5K' },
  { rank: 2, name: 'DeFi Protocol', gain: '+180%', holders: '8.2K' },
  { rank: 3, name: 'GameFi Token', gain: '+156%', holders: '15.1K' },
];

export default function Leaderboard() {
  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Trophy className="w-5 h-5 text-yellow-500" />
        Top Performers
      </h3>
      
      <div className="space-y-4">
        {leaderboardData.map((item) => (
          <div key={item.rank} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
            <div className="flex items-center gap-3">
              <span className="text-lg font-bold text-gray-400">#{item.rank}</span>
              <span className="font-medium">{item.name}</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <TrendingUp className="w-4 h-4 text-green-500" />
                <span className="text-green-500">{item.gain}</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4 text-gray-400" />
                <span className="text-gray-400">{item.holders}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
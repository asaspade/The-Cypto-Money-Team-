import React from 'react';
import { ArrowLeft, ExternalLink, Share2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../utils/navigation';

interface TokenHeaderProps {
  name: string;
  symbol: string;
  address: string;
  imageUrl?: string;
}

export default function TokenHeader({ name, symbol, address, imageUrl }: TokenHeaderProps) {
  const navigate = useNavigate();
  const shortenAddress = (addr: string) => 
    `${addr.slice(0, 6)}...${addr.slice(-4)}`;

  return (
    <div className="border-b border-primary-500/20 pb-6">
      <div className="flex items-center gap-4 mb-4">
        <button 
          onClick={() => navigate(routes.home)}
          className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-primary-500" />
        </button>
        
        <div className="flex items-center gap-4">
          {imageUrl && (
            <img 
              src={imageUrl} 
              alt={`${name} logo`}
              className="w-12 h-12 rounded-full border border-primary-500/20"
            />
          )}
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
              {name}
            </h1>
            <span className="text-primary-400">{symbol}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="text-gray-400">Contract:</span>
          <span className="font-mono text-primary-400">{shortenAddress(address)}</span>
          <button className="p-1 hover:bg-primary-500/20 rounded transition-colors">
            <ExternalLink className="w-4 h-4 text-primary-400" />
          </button>
        </div>
        <button className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors">
          <Share2 className="w-4 h-4 text-primary-400" />
        </button>
      </div>
    </div>
  );
}
import React from 'react';
import { LineChart, Clock } from 'lucide-react';

const timeframes = ['1D', '1W', '1M', '3M', '1Y', 'ALL'];

export default function PortfolioChart() {
  return (
    <div className="stats-card">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <LineChart className="w-5 h-5 text-primary-500" />
          Portfolio Value
        </h3>
        <div className="flex items-center gap-2">
          {timeframes.map((tf) => (
            <button
              key={tf}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors
                ${tf === '1M' 
                  ? 'bg-primary-500/20 text-primary-400' 
                  : 'text-gray-400 hover:text-primary-400'}`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      <div className="h-64 flex items-center justify-center">
        <div className="text-center text-gray-400">
          <Clock className="w-12 h-12 mx-auto mb-4 text-primary-500/50" />
          <p>Portfolio history will be available after connecting your wallet</p>
        </div>
      </div>
    </div>
  );
}
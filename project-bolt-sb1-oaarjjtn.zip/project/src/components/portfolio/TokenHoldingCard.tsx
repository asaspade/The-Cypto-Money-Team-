import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { TokenHolding } from '../../types/token';
import BlockchainBadge from '../blockchain/BlockchainBadge';

export default function TokenHoldingCard({
  name,
  symbol,
  balance,
  value,
  priceChange24h,
  chainId,
  imageUrl,
}: TokenHolding) {
  const isPositive = priceChange24h >= 0;

  return (
    <div className="stats-card hover:scale-[1.02] transition-transform duration-300">
      <div className="flex items-center gap-4 mb-4">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={`${name} logo`}
            className="w-12 h-12 rounded-xl"
          />
        ) : (
          <div className="w-12 h-12 rounded-xl bg-primary-500/10 flex items-center justify-center">
            <span className="text-xl font-bold text-primary-400">{symbol[0]}</span>
          </div>
        )}
        <div>
          <h3 className="font-bold text-lg">{name}</h3>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">{symbol}</span>
            <BlockchainBadge chainId={chainId} showName={false} />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <div className="text-sm text-gray-400 mb-1">Balance</div>
          <div className="text-lg font-bold">{balance} {symbol}</div>
        </div>

        <div className="flex justify-between items-end">
          <div>
            <div className="text-sm text-gray-400 mb-1">Value</div>
            <div className="text-lg font-bold">${value.toLocaleString()}</div>
          </div>
          <div className={`flex items-center gap-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span>{isPositive ? '+' : ''}{priceChange24h}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
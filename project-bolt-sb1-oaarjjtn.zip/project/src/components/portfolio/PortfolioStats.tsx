import React from 'react';
import { DollarSign, TrendingUp, Clock, Activity } from 'lucide-react';

interface PortfolioStatsProps {
  totalValue: number;
}

export default function PortfolioStats({ totalValue }: PortfolioStatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="stats-card">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-primary-500/20">
            <DollarSign className="w-6 h-6 text-primary-500" />
          </div>
          <div>
            <div className="text-sm text-gray-400">Total Value</div>
            <div className="text-xl font-bold">${totalValue.toLocaleString()}</div>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-green-500/20">
            <TrendingUp className="w-6 h-6 text-green-500" />
          </div>
          <div>
            <div className="text-sm text-gray-400">24h Change</div>
            <div className="text-xl font-bold text-green-500">+5.2%</div>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-blue-500/20">
            <Activity className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <div className="text-sm text-gray-400">Active Positions</div>
            <div className="text-xl font-bold">8</div>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-purple-500/20">
            <Clock className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <div className="text-sm text-gray-400">Avg. Hold Time</div>
            <div className="text-xl font-bold">45 days</div>
          </div>
        </div>
      </div>
    </div>
  );
}
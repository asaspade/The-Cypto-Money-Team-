import React from 'react';
import { Crown, Loader2, RefreshCw } from 'lucide-react';
import { useVitruveoTokens } from '../../hooks/useVitruveoTokens';
import PremiumTokenCard from './PremiumTokenCard';

export default function PremiumTokens() {
  const { tokens, isLoading, refresh } = useVitruveoTokens();

  if (!tokens.length) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Crown className="w-6 h-6 text-yellow-500" />
          <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-yellow-600">
            Premium Tokens
          </h2>
        </div>
        <button
          onClick={refresh}
          disabled={isLoading}
          className="flex items-center gap-2 text-primary-400 hover:text-primary-500 transition-colors disabled:opacity-50"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
          <span>{isLoading ? 'Updating...' : 'Refresh'}</span>
        </button>
      </div>

      <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-primary-500/20 scrollbar-track-transparent">
        {tokens.map((token) => (
          <PremiumTokenCard 
            key={token.id}
            {...token}
          />
        ))}
      </div>
    </div>
  );
}
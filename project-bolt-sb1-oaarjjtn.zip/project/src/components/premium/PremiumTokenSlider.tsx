import React, { useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import PremiumTokenCard from './PremiumTokenCard';
import { usePremiumTokens } from '../../hooks/usePremiumTokens';

export default function PremiumTokenSlider() {
  const sliderRef = useRef<HTMLDivElement>(null);
  const { tokens, isLoading } = usePremiumTokens();

  useEffect(() => {
    const interval = setInterval(() => {
      if (sliderRef.current) {
        const firstCard = sliderRef.current.firstElementChild as HTMLElement;
        if (firstCard) {
          sliderRef.current.scrollLeft += firstCard.offsetWidth + 24; // 24 is gap
          
          // Reset scroll if at end
          if (sliderRef.current.scrollLeft >= sliderRef.current.scrollWidth - sliderRef.current.offsetWidth) {
            sliderRef.current.scrollLeft = 0;
          }
        }
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const scrollAmount = direction === 'left' ? -400 : 400;
      sliderRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  if (isLoading || !tokens.length) return null;

  return (
    <div className="relative group">
      <button 
        onClick={() => scroll('left')}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <ChevronLeft className="w-6 h-6 text-white" />
      </button>

      <div 
        ref={sliderRef}
        className="flex gap-6 overflow-x-auto scrollbar-none scroll-smooth pb-4"
      >
        {tokens.slice(0, 6).map((token) => (
          <PremiumTokenCard 
            key={token.id}
            {...token}
          />
        ))}
      </div>

      <button 
        onClick={() => scroll('right')}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <ChevronRight className="w-6 h-6 text-white" />
      </button>
    </div>
  );
}
import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart2 } from 'lucide-react';

interface PremiumTokenCardProps {
  name: string;
  symbol: string;
  price: string;
  change: string;
  isPositive: boolean;
  marketCap: string;
  volume24h: string;
}

export default function PremiumTokenCard({
  name,
  symbol,
  price,
  change,
  isPositive,
  marketCap,
  volume24h
}: PremiumTokenCardProps) {
  return (
    <div className="flex-shrink-0 w-72 bg-gradient-to-br from-gray-900 to-black rounded-xl border border-primary-500/20 hover:border-primary-500/40 transition-all duration-300 p-4 group cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-primary-500/10 border border-primary-500/20 flex items-center justify-center">
          <span className="text-xl font-bold text-primary-400">{symbol[0]}</span>
        </div>
        <div>
          <h3 className="font-bold text-white group-hover:text-primary-400 transition-colors">
            {name}
          </h3>
          <span className="text-sm text-gray-400">{symbol}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div>
            <div className="text-sm text-gray-400 mb-1">Price</div>
            <div className="text-lg font-bold text-white">{price}</div>
          </div>
          <div className={`flex items-center gap-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span className="font-medium">{change}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-primary-500/10">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-primary-400" />
            <div>
              <div className="text-xs text-gray-400">Market Cap</div>
              <div className="text-sm font-medium">{marketCap}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-primary-400" />
            <div>
              <div className="text-xs text-gray-400">24h Volume</div>
              <div className="text-sm font-medium">{volume24h}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart2, Users, Globe, Twitter } from 'lucide-react';
import { Link } from 'react-router-dom';

interface PremiumTokenListItemProps {
  id: string;
  name: string;
  symbol: string;
  price: string;
  change: string;
  isPositive: boolean;
  marketCap: string;
  volume24h: string;
  holders: number;
  description?: string;
  website?: string;
  twitter?: string;
  imageUrl?: string;
}

export default function PremiumTokenListItem({
  id,
  name,
  symbol,
  price,
  change,
  isPositive,
  marketCap,
  volume24h,
  holders = 0,
  description,
  website,
  twitter,
  imageUrl,
}: PremiumTokenListItemProps) {
  return (
    <div className="stats-card hover:scale-[1.01] transition-transform duration-300">
      <div className="flex items-start gap-8">
        {/* Larger image container */}
        <div className="flex-shrink-0">
          {imageUrl ? (
            <img 
              src={imageUrl.replace('w=100', 'w=200').replace('h=100', 'h=200')} 
              alt={name}
              className="w-32 h-32 rounded-2xl object-cover border border-primary-500/20"
            />
          ) : (
            <div className="w-32 h-32 rounded-2xl bg-primary-500/10 flex items-center justify-center border border-primary-500/20">
              <span className="text-4xl font-bold text-primary-400">{symbol[0]}</span>
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-4">
            <div>
              <Link 
                to={`/token/${id}`}
                className="text-2xl font-bold hover:text-primary-400 transition-colors"
              >
                {name}
              </Link>
              <div className="flex items-center gap-4 mt-2">
                <span className="text-lg text-gray-400">{symbol}</span>
                <div className={`flex items-center gap-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                  {isPositive ? (
                    <TrendingUp className="w-5 h-5" />
                  ) : (
                    <TrendingDown className="w-5 h-5" />
                  )}
                  <span className="text-lg">{change}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">{price}</div>
              <div className="text-sm text-gray-400">Current Price</div>
            </div>
          </div>

          {description && (
            <p className="text-gray-400 mb-6 text-lg line-clamp-2">{description}</p>
          )}

          <div className="grid grid-cols-3 gap-6 mb-6">
            <div className="flex items-center gap-3">
              <DollarSign className="w-5 h-5 text-primary-400" />
              <div>
                <div className="text-sm text-gray-400">Market Cap</div>
                <div className="font-medium text-lg">{marketCap}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <BarChart2 className="w-5 h-5 text-primary-400" />
              <div>
                <div className="text-sm text-gray-400">24h Volume</div>
                <div className="font-medium text-lg">{volume24h}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-primary-400" />
              <div>
                <div className="text-sm text-gray-400">Holders</div>
                <div className="font-medium text-lg">{holders.toLocaleString()}</div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            {website && (
              <a 
                href={website}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-primary-400 transition-colors"
              >
                <Globe className="w-5 h-5" />
                Website
              </a>
            )}
            {twitter && (
              <a 
                href={twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-primary-400 transition-colors"
              >
                <Twitter className="w-5 h-5" />
                Twitter
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import LeaderboardCard from './LeaderboardCard';
import { volumeLeaders, topGainers, topDeclining } from '../../data/leaderboardData';

export default function MarketLeaderboard() {
  return (
    <div className="space-y-6">
      <LeaderboardCard
        title="Top Volume"
        type="volume"
        tokens={volumeLeaders}
      />
      <LeaderboardCard
        title="Top Gainers"
        type="gainers"
        tokens={topGainers}
      />
      <LeaderboardCard
        title="Top Declining"
        type="declining"
        tokens={topDeclining}
      />
    </div>
  );
}
import React from 'react';
import { TrendingUp, TrendingDown, BarChart2 } from 'lucide-react';

interface TokenStats {
  name: string;
  symbol: string;
  value: string;
  change: string;
  isPositive?: boolean;
}

interface LeaderboardCardProps {
  title: string;
  type: 'volume' | 'gainers' | 'declining';
  tokens: TokenStats[];
}

export default function LeaderboardCard({ title, type, tokens }: LeaderboardCardProps) {
  const getIcon = () => {
    switch (type) {
      case 'volume':
        return <BarChart2 className="w-5 h-5 text-primary-500" />;
      case 'gainers':
        return <TrendingUp className="w-5 h-5 text-green-500" />;
      case 'declining':
        return <TrendingDown className="w-5 h-5 text-red-500" />;
    }
  };

  return (
    <div className="stats-card">
      <h3 className="section-title mb-4 flex items-center gap-2">
        {getIcon()}
        {title}
      </h3>
      
      <div className="space-y-4">
        {tokens.map((token, index) => (
          <div key={token.symbol} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-primary-400">#{index + 1}</span>
              <div>
                <div className="font-medium">{token.name}</div>
                <div className="text-sm text-gray-400">{token.symbol}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-medium">{token.value}</div>
              <div className={`text-sm ${token.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {token.change}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
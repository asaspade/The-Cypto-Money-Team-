import React from 'react';
import { Trophy, Star, Target } from 'lucide-react';
import { useTokenCreators } from '../../hooks/useTokenCreators';
import BlockchainBadge from '../blockchain/BlockchainBadge';

export default function TokenCreatorsLeaderboard() {
  const { creators, isLoading } = useTokenCreators();

  if (isLoading) {
    return (
      <div className="stats-card animate-pulse">
        <div className="h-6 w-1/3 bg-gray-800 rounded mb-6" />
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-800 rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
        <Trophy className="w-5 h-5 text-yellow-500" />
        <span>Top Token Creators</span>
      </h3>

      <div className="space-y-4">
        {creators.map((creator, index) => (
          <div 
            key={creator.address}
            className="flex items-center gap-4 p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors"
          >
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary-500/20 flex items-center justify-center">
              {index === 0 ? (
                <Trophy className="w-4 h-4 text-yellow-500" />
              ) : index === 1 ? (
                <Star className="w-4 h-4 text-gray-300" />
              ) : index === 2 ? (
                <Target className="w-4 h-4 text-amber-600" />
              ) : (
                <span className="text-sm font-bold text-gray-400">#{index + 1}</span>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium truncate">
                  {creator.name || `${creator.address.slice(0, 6)}...${creator.address.slice(-4)}`}
                </span>
                {creator.isVerified && (
                  <span className="text-xs bg-primary-500/20 text-primary-400 px-2 py-0.5 rounded-full">
                    Verified
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <span>{creator.tokensCreated} tokens</span>
                <span>•</span>
                <span>${creator.totalValue.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {creator.chains.map((chain) => (
                <BlockchainBadge key={chain} chainId={chain} showName={false} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { Handshake } from 'lucide-react';

const partners = [
  {
    name: 'Ethereum',
    logo: 'https://images.unsplash.com/photo-1622790698141-94e30457ef12?auto=format&fit=crop&w=200&h=100&q=80',
  },
  {
    name: 'Binance',
    logo: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=200&h=100&q=80',
  },
  {
    name: 'Polygon',
    logo: 'https://images.unsplash.com/photo-1622790698141-94e30457ef12?auto=format&fit=crop&w=200&h=100&q=80',
  },
  {
    name: 'Chainlink',
    logo: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=200&h=100&q=80',
  },
];

export default function Partners() {
  return (
    <div className="bg-gray-900/50 backdrop-blur-sm border-y border-primary-500/20 py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-12 justify-center">
          <Handshake className="w-8 h-8 text-primary-500" />
          <h2 className="text-3xl font-bold text-center">Our Partners</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {partners.map((partner) => (
            <div 
              key={partner.name}
              className="flex items-center justify-center p-6 bg-gray-800/50 rounded-xl hover:bg-gray-800/70 transition-all duration-300 border border-primary-500/10 hover:border-primary-500/30"
            >
              <img 
                src={partner.logo} 
                alt={partner.name} 
                className="max-h-12 w-auto filter brightness-0 invert opacity-70 hover:opacity-100 transition-opacity"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Star } from 'lucide-react';
import TokenCard from '../TokenCard';
import { featuredTokens } from '../../data/mockTokenData';

export default function FeaturedProjects() {
  return (
    <div className="py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <Star className="w-6 h-6 text-purple-500" />
          <h2 className="text-2xl font-bold">Featured Projects</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredTokens.map((token) => (
            <TokenCard key={token.id} {...token} />
          ))}
        </div>
      </div>
    </div>
  );
}
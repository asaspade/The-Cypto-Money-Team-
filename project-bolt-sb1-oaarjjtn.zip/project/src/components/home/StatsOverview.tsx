import React from 'react';
import { Users, Rocket, DollarSign } from 'lucide-react';

const stats = [
  {
    icon: DollarSign,
    label: 'Total Value Locked',
    value: '$125M+',
  },
  {
    icon: Users,
    label: 'Total Participants',
    value: '50K+',
  },
  {
    icon: Rocket,
    label: 'Successful Launches',
    value: '85+',
  },
];

export default function StatsOverview() {
  return (
    <div className="bg-gray-900/50 backdrop-blur-sm border-y border-primary-500/20 py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map(({ icon: Icon, label, value }) => (
            <div key={label} className="flex items-center gap-4">
              <div className="bg-primary-500/20 p-4 rounded-xl">
                <Icon className="w-8 h-8 text-primary-500" />
              </div>
              <div>
                <p className="text-gray-400">{label}</p>
                <p className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
                  {value}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
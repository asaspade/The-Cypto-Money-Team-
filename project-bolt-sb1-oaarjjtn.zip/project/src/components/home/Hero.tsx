import React from 'react';
import { Rocket, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../../utils/navigation';
import ConnectWalletButton from '../common/ConnectWalletButton';
import SupportedChains from '../blockchain/SupportedChains';

export default function Hero() {
  const navigate = useNavigate();

  return (
    <div className="relative gradient-animate py-12 md:py-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 md:gap-3 mb-6">
            <Rocket className="w-8 md:w-12 h-8 md:h-12 text-primary-500" />
            <h1 className="text-3xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
              Multi-Chain Token Launcher
            </h1>
          </div>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Launch your token on multiple leading blockchain platforms with guaranteed security and transparency.
          </p>
          <SupportedChains />
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
            <ConnectWalletButton />
            <button 
              onClick={() => navigate(routes.createToken)}
              className="btn-primary flex items-center gap-2 w-full sm:w-auto"
            >
              <Plus className="w-5 h-5" />
              Create Token
            </button>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black to-transparent"></div>
    </div>
  );
}
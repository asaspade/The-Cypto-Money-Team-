import React from 'react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../utils/navigation';
import BlockchainBadge from './blockchain/BlockchainBadge';
import TokenCardStats from './token/TokenCardStats';
import TokenCardTimer from './token/TokenCardTimer';
import TokenCardProgress from './token/TokenCardProgress';

interface TokenCardProps {
  id: string;
  name: string;
  symbol: string;
  price: string;
  progress: number;
  timeLeft: string;
  participants: number;
  raised: string;
  imageUrl?: string;
  chainId: string;
}

export default function TokenCard({
  id,
  name,
  symbol,
  price,
  progress,
  timeLeft,
  participants,
  raised,
  imageUrl,
  chainId,
}: TokenCardProps) {
  const navigate = useNavigate();

  return (
    <div 
      onClick={() => navigate(routes.tokenDetail(id))}
      className="group relative overflow-hidden bg-gradient-to-br from-gray-900 to-black rounded-xl border border-primary-500/10 hover:border-primary-500/30 transition-all duration-300 cursor-pointer"
    >
      {/* Background Glow Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary-500/0 via-primary-500/5 to-primary-500/0 group-hover:via-primary-500/10 transition-all duration-500" />
      
      {/* Content */}
      <div className="relative p-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-4">
            {imageUrl ? (
              <img 
                src={imageUrl} 
                alt={`${name} logo`}
                className="w-12 h-12 rounded-xl border border-primary-500/20"
              />
            ) : (
              <div className="w-12 h-12 rounded-xl bg-primary-500/10 border border-primary-500/20" />
            )}
            <div>
              <h3 className="text-xl font-bold text-white group-hover:text-primary-400 transition-colors">
                {name}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-gray-400">{symbol}</span>
                <BlockchainBadge chainId={chainId} />
              </div>
            </div>
          </div>
          <div className="px-3 py-1 rounded-full bg-primary-500/10 border border-primary-500/20">
            <span className="text-primary-400 text-sm font-medium">Live</span>
          </div>
        </div>

        {/* Timer */}
        <TokenCardTimer timeLeft={timeLeft} />

        {/* Progress */}
        <TokenCardProgress progress={progress} raised={raised} />

        {/* Stats */}
        <TokenCardStats 
          price={price}
          participants={participants}
          marketCap="$2.5M"
          totalSupply="100M"
        />
      </div>
    </div>
  );
}
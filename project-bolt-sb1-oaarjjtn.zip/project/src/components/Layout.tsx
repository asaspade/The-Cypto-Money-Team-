import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './footer/Footer';
import TokenTicker from './TokenTicker';
import { useScrollToTop } from '../hooks/useScrollToTop';

export default function Layout() {
  useScrollToTop();

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col">
      <TokenTicker />
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
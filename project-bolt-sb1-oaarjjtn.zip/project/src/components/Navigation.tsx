import React from 'react';
import { Star, TrendingUp, UserCircle, Clock, Activity, Crown } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { routes } from '../utils/navigation';

const tabs = [
  { name: 'All coins', icon: TrendingUp, path: '/' },
  { name: 'Premium', icon: Crown, path: routes.premiumTokens },
  { name: 'Following', icon: Star, path: '/following' },
  { name: 'My coins', icon: UserCircle, path: '/my-coins' },
  { name: 'Static', icon: Clock, path: '/static' },
  { name: 'Live', icon: Activity, path: '/live' },
];

export default function Navigation() {
  const location = useLocation();

  return (
    <div className="border-b border-primary-500/20 mb-6 overflow-x-auto scrollbar-thin scrollbar-thumb-primary-500/20 scrollbar-track-transparent">
      <div className="flex items-center gap-2 md:gap-6 mb-4 min-w-max px-4 md:px-0">
        {tabs.map(({ name, icon: Icon, path }) => (
          <Link
            key={path}
            to={path}
            className={`flex items-center gap-2 px-3 md:px-4 py-2 rounded-lg transition-colors ${
              location.pathname === path
                ? 'bg-primary-500/20 text-primary-500'
                : 'text-gray-400 hover:text-primary-500 hover:bg-primary-500/10'
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm md:text-base whitespace-nowrap">{name}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../utils/navigation';

export default function KYCButton() {
  const navigate = useNavigate();

  return (
    <button 
      onClick={() => navigate(routes.getKyc)}
      className="flex items-center gap-2 px-4 py-2 bg-primary-500/20 text-primary-400 rounded-lg hover:bg-primary-500/30 transition-colors"
    >
      <Shield className="w-5 h-5" />
      <span>Get KYC</span>
    </button>
  );
}
import React from 'react';
import { supportedChains } from '../../config/chains';
import BlockchainIcon from './BlockchainIcon';

export default function SupportedChains() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      {supportedChains.map((chain) => (
        <div 
          key={chain.id}
          className="flex items-center gap-2 px-4 py-2 bg-gray-900/50 rounded-lg border border-primary-500/20"
        >
          <BlockchainIcon chainId={chain.id} />
          <span className="text-gray-300">{chain.name}</span>
        </div>
      ))}
    </div>
  );
}
import React from 'react';
import { supportedChains } from '../../config/chains';
import BlockchainIcon from './BlockchainIcon';

interface BlockchainTabsProps {
  selectedChain: string;
  onSelect: (chainId: string) => void;
}

export default function BlockchainTabs({ selectedChain, onSelect }: BlockchainTabsProps) {
  return (
    <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-primary-500/20 scrollbar-track-transparent">
      <button
        onClick={() => onSelect('all')}
        className={`btn-secondary whitespace-nowrap min-w-max ${
          selectedChain === 'all' ? 'bg-primary-500/20 border-primary-500' : ''
        }`}
      >
        All Chains
      </button>
      
      {supportedChains.map((chain) => (
        <button
          key={chain.id}
          onClick={() => onSelect(chain.id)}
          className={`btn-secondary flex items-center gap-2 whitespace-nowrap min-w-max ${
            selectedChain === chain.id ? 'bg-primary-500/20 border-primary-500' : ''
          }`}
        >
          <BlockchainIcon chainId={chain.id} />
          {chain.name}
        </button>
      ))}
    </div>
  );
}
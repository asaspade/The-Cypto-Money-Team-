import React from 'react';
import { BarChart3 } from 'lucide-react';
import { useChainStats } from '../../hooks/useChainStats';
import BlockchainIcon from './BlockchainIcon';

export default function ChainPopularityMeter() {
  const { chainStats, isLoading } = useChainStats();

  if (isLoading) {
    return (
      <div className="stats-card animate-pulse">
        <div className="h-6 w-1/3 bg-gray-800 rounded mb-6" />
        <div className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-12 bg-gray-800 rounded" />
          ))}
        </div>
      </div>
    );
  }

  const totalTokens = chainStats.reduce((sum, stat) => sum + stat.tokenCount, 0);

  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
        <BarChart3 className="w-5 h-5 text-primary-500" />
        <span>Chain Popularity</span>
      </h3>

      <div className="space-y-4">
        {chainStats.map((stat) => {
          const percentage = (stat.tokenCount / totalTokens) * 100;
          
          return (
            <div key={stat.chainId}>
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <BlockchainIcon chainId={stat.chainId} />
                  <span className="font-medium">{stat.name}</span>
                </div>
                <div className="text-sm">
                  <span className="text-primary-400">{stat.tokenCount}</span>
                  <span className="text-gray-400"> tokens</span>
                </div>
              </div>
              <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary-500 to-primary-600 rounded-full transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <div className="text-right text-xs text-primary-400 mt-1">
                {percentage.toFixed(1)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
import React from 'react';
import { supportedChains } from '../../config/chains';
import BlockchainIcon from './BlockchainIcon';

interface BlockchainBadgeProps {
  chainId: string;
  showName?: boolean;
}

export default function BlockchainBadge({ chainId, showName = true }: BlockchainBadgeProps) {
  const chain = supportedChains.find(c => c.id === chainId);
  if (!chain) return null;

  return (
    <div className="inline-flex items-center gap-1.5 px-2 py-1 bg-gray-800/50 rounded-full text-sm">
      <BlockchainIcon chainId={chainId} className="w-3.5 h-3.5" />
      {showName && <span className="text-gray-300">{chain.name}</span>}
    </div>
  );
}
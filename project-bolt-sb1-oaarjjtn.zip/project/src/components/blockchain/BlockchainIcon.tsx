import React from 'react';
import { Coins } from 'lucide-react';

interface BlockchainIconProps {
  chainId: string;
  className?: string;
}

export default function BlockchainIcon({ chainId, className = "w-4 h-4" }: BlockchainIconProps) {
  return <Coins className={`${className} ${getChainColor(chainId)}`} />;
}

function getChainColor(chainId: string): string {
  switch (chainId) {
    case 'vitruveo':
      return 'text-primary-500';
    case 'pulsechain':
      return 'text-red-500';
    case 'solana':
      return 'text-purple-500';
    case 'bnb':
      return 'text-yellow-500';
    default:
      return 'text-gray-400';
  }
}
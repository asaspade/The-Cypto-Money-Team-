import React from 'react';
import { Rocket } from 'lucide-react';

interface BlastOffMeterProps {
  progress: number;
  targetDate: string;
}

export default function BlastOffMeter({ progress, targetDate }: BlastOffMeterProps) {
  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Rocket className="w-5 h-5 text-primary-500" />
        Blast Off Meter
      </h3>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm text-gray-400 mb-2">
            <span>Progress to Launch</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full bg-gray-800 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-primary-500 to-primary-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        
        <div className="text-center">
          <div className="text-gray-400 text-sm">Estimated Launch Date</div>
          <div className="font-semibold text-lg text-primary-400">{targetDate}</div>
        </div>
      </div>
    </div>
  );
}
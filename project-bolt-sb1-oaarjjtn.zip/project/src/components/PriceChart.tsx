import React from 'react';
import { LineChart, TrendingUp } from 'lucide-react';

export default function PriceChart() {
  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <LineChart className="w-5 h-5 text-primary-500" />
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Price Chart
        </span>
      </h3>
      
      <div className="flex items-center justify-center h-64 bg-gray-800/50 rounded-lg border border-primary-500/10">
        <div className="text-center text-gray-400">
          <TrendingUp className="w-12 h-12 mx-auto mb-4 text-primary-500/50" />
          <p>Price chart will be available after launch</p>
        </div>
      </div>
    </div>
  );
}
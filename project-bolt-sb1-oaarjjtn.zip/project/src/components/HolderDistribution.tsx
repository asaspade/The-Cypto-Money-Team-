import React from 'react';
import { Users } from 'lucide-react';

interface HolderGroup {
  range: string;
  percentage: number;
  count: number;
}

interface HolderDistributionProps {
  distribution: HolderGroup[];
  totalHolders: number;
}

export default function HolderDistribution({ distribution, totalHolders }: HolderDistributionProps) {
  return (
    <div className="stats-card">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Holder Distribution
        </h3>
        <div className="flex items-center gap-2 text-primary-400">
          <Users className="w-5 h-5" />
          <span>{totalHolders.toLocaleString()} holders</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {distribution.map((group) => (
          <div key={group.range}>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">{group.range}</span>
              <span className="text-primary-400">{group.count.toLocaleString()} addresses</span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-primary-500 to-primary-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${group.percentage}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
import React, { useEffect } from 'react';

declare global {
  interface Window {
    gecko_coin_price_chart_widget: any;
  }
}

export default function CoinGeckoChart() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://widgets.coingecko.com/gecko-coin-price-chart-widget.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="stats-card">
      <gecko-coin-price-chart-widget 
        locale="en" 
        dark-mode="true" 
        transparent-background="true" 
        outlined="true" 
        coin-id="wrapped-vtru" 
        initial-currency="usd"
      />
    </div>
  );
}
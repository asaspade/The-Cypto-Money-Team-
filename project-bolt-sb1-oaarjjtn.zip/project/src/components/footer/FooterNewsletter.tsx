import React from 'react';
import { Send } from 'lucide-react';

export default function FooterNewsletter() {
  return (
    <div className="lg:col-span-2">
      <h3 className="text-lg font-semibold mb-4 text-primary-400">Stay Updated</h3>
      <p className="text-gray-400 mb-4">
        Subscribe to our newsletter for the latest updates and token launches.
      </p>
      <form className="flex gap-2">
        <input
          type="email"
          placeholder="Enter your email"
          className="flex-1 bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
        />
        <button 
          type="submit"
          className="btn-primary !px-4"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
}
import React from 'react';
import { Rocket } from 'lucide-react';
import FooterLinks from './FooterLinks';
import FooterNewsletter from './FooterNewsletter';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-black via-gray-900 to-black border-t border-primary-500/20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-5 gap-12">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Rocket className="w-8 h-8 text-primary-500" />
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
                Crypto Launcher
              </span>
            </div>
            <p className="text-gray-400 mb-4">
              The next generation token launcher platform. Secure, transparent, and efficient.
            </p>
            <FooterNewsletter />
          </div>
          
          <div className="lg:col-span-3">
            <FooterLinks />
          </div>
        </div>
        
        <div className="border-t border-primary-500/10 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Crypto Launcher. All rights reserved. 
            <span className="block mt-1 text-primary-400">
              Created and Built by The Crypto Money Team
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}
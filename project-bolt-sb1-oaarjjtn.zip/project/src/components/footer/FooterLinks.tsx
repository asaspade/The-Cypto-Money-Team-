import React from 'react';
import { Link } from 'react-router-dom';
import { routes } from '../../utils/navigation';

interface LinkGroup {
  title: string;
  links: Array<{
    name: string;
    href: string;
  }>;
}

const linkGroups: LinkGroup[] = [
  {
    title: 'Platform',
    links: [
      { name: 'How it Works', href: routes.howItWorks },
      { name: 'Roadmap', href: routes.roadmap },
      { name: 'Features', href: '#' },
      { name: 'Security', href: '#' },
    ],
  },
  {
    title: 'Resources',
    links: [
      { name: 'Documentation', href: '#' },
      { name: 'API', href: '#' },
      { name: 'Status', href: '#' },
      { name: 'Terms of Service', href: '#' },
    ],
  },
  {
    title: 'Community',
    links: [
      { name: 'Discord', href: '#' },
      { name: 'Twitter', href: '#' },
      { name: 'Telegram', href: '#' },
      { name: 'Blog', href: '#' },
    ],
  },
];

export default function FooterLinks() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
      {linkGroups.map((group) => (
        <div key={group.title}>
          <h3 className="text-lg font-semibold mb-4 text-primary-400">{group.title}</h3>
          <ul className="space-y-2">
            {group.links.map((link) => (
              <li key={link.name}>
                <Link 
                  to={link.href}
                  className="text-gray-400 hover:text-primary-500 transition-colors"
                >
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
import React from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';

export default function TokenFilters() {
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search tokens..."
            className="bg-gray-900 border border-gray-800 rounded-lg py-2 px-4 pl-10 focus:outline-none focus:border-primary-500 w-64"
          />
          <Search className="w-5 h-5 text-primary-400 absolute left-3 top-2.5" />
        </div>
        
        <select className="bg-gray-900 border border-gray-800 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500">
          <option>Sort by: Newest</option>
          <option>Sort by: Oldest</option>
          <option>Sort by: Most Popular</option>
          <option>Sort by: Highest Gain</option>
        </select>
      </div>
      
      <button className="flex items-center gap-2 px-4 py-2 bg-gray-900 border border-gray-800 rounded-lg hover:border-primary-500 transition-colors">
        <SlidersHorizontal className="w-4 h-4 text-primary-400" />
        <span>Filters</span>
      </button>
    </div>
  );
}
import React from 'react';
import { TrendingUp, Users, Rocket } from 'lucide-react';

export default function Stats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
        <div className="flex items-center gap-4">
          <div className="bg-purple-500/20 p-3 rounded-lg">
            <TrendingUp className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <p className="text-gray-400">Total Value Locked</p>
            <h4 className="text-2xl font-bold text-white">$12.5M</h4>
          </div>
        </div>
      </div>

      <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
        <div className="flex items-center gap-4">
          <div className="bg-purple-500/20 p-3 rounded-lg">
            <Users className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <p className="text-gray-400">Total Participants</p>
            <h4 className="text-2xl font-bold text-white">15.2K</h4>
          </div>
        </div>
      </div>

      <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
        <div className="flex items-center gap-4">
          <div className="bg-purple-500/20 p-3 rounded-lg">
            <Rocket className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <p className="text-gray-400">Projects Launched</p>
            <h4 className="text-2xl font-bold text-white">156</h4>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { BarChart2, DollarSign, Users, Rocket } from 'lucide-react';

const metrics = [
  {
    icon: DollarSign,
    label: "Total Value Locked",
    value: "$125M+",
    change: "+15%"
  },
  {
    icon: Users,
    label: "Active Users",
    value: "50K+",
    change: "+25%"
  },
  {
    icon: Rocket,
    label: "Successful Launches",
    value: "85+",
    change: "+10%"
  },
  {
    icon: BarChart2,
    label: "Trading Volume",
    value: "$45M+",
    change: "+20%"
  }
];

export default function RoadmapMetrics() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold">Platform Metrics</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="stats-card">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary-500/20 rounded-lg">
                  <Icon className="w-6 h-6 text-primary-500" />
                </div>
                <div>
                  <div className="text-sm text-gray-400">{metric.label}</div>
                  <div className="text-xl font-bold">{metric.value}</div>
                </div>
              </div>
              <div className="text-sm text-green-500">
                {metric.change} this month
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
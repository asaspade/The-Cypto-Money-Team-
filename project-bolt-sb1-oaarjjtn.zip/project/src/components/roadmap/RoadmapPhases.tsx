import React from 'react';
import { Target } from 'lucide-react';

const phases = [
  {
    title: "Phase 1: Foundation",
    timeline: "Q1 2024",
    items: [
      "Multi-chain integration",
      "Basic token creation tools",
      "KYC verification system",
      "Initial security audits"
    ]
  },
  {
    title: "Phase 2: Growth",
    timeline: "Q2 2024",
    items: [
      "Advanced bonding curves",
      "Gamified launch events",
      "Enhanced analytics",
      "Community governance"
    ]
  },
  {
    title: "Phase 3: Expansion",
    timeline: "Q3-Q4 2024",
    items: [
      "Cross-chain bridges",
      "Advanced trading features",
      "Mobile application",
      "Developer API"
    ]
  }
];

export default function RoadmapPhases() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3 mb-8">
        <Target className="w-6 h-6 text-primary-500" />
        <h2 className="text-2xl font-bold">Development Phases</h2>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {phases.map((phase, index) => (
          <div key={index} className="stats-card">
            <div className="mb-4">
              <h3 className="text-xl font-bold text-primary-400">{phase.title}</h3>
              <p className="text-sm text-gray-400">{phase.timeline}</p>
            </div>
            <ul className="space-y-3">
              {phase.items.map((item, itemIndex) => (
                <li key={itemIndex} className="flex items-center gap-2 text-gray-400">
                  <span className="w-2 h-2 rounded-full bg-primary-500" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { Layers, Shield, Rocket, Users } from 'lucide-react';

const features = [
  {
    icon: Layers,
    title: "Multi-Chain Support",
    description: "Launch tokens across multiple blockchains with unified management and monitoring."
  },
  {
    icon: Shield,
    title: "Enhanced Security",
    description: "Advanced security measures including KYC verification and smart contract audits."
  },
  {
    icon: Rocket,
    title: "Gamified Launches",
    description: "Interactive launch mechanics with milestones and community rewards."
  },
  {
    icon: Users,
    title: "Community Focus",
    description: "Built-in tools for community engagement and token holder management."
  }
];

export default function RoadmapFeatures() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold">Key Features</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <div key={index} className="stats-card">
              <Icon className="w-8 h-8 text-primary-500 mb-4" />
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-400">{feature.description}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
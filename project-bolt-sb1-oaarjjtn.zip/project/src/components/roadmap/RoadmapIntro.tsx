import React from 'react';
import { Rocket } from 'lucide-react';
import { PLATFORM_FEES } from '../../config/fees';

export default function RoadmapIntro() {
  return (
    <div className="stats-card">
      <div className="flex items-center gap-3 mb-6">
        <Rocket className="w-6 h-6 text-primary-500" />
        <h2 className="text-2xl font-bold">Vision & Mission</h2>
      </div>
      <p className="text-gray-400 mb-6">
        Crypto Launcher is revolutionizing token creation and distribution through a decentralized, 
        gamified platform. Our mission is to empower developers with accessible tools while maintaining 
        high security standards and fostering community engagement.
      </p>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-primary-500/10 p-4 rounded-lg">
          <h3 className="font-bold mb-2">Platform Fee</h3>
          <p className="text-sm text-gray-400">
            ${PLATFORM_FEES.LISTING_FEE} USDC (BNB) one-time listing fee + {PLATFORM_FEES.TRANSACTION_FEE_PERCENT}% transaction fee on all trades
          </p>
        </div>
        <div className="bg-primary-500/10 p-4 rounded-lg">
          <h3 className="font-bold mb-2">Supported Networks</h3>
          <p className="text-sm text-gray-400">
            Vitruveo, Binance Smart Chain, Solana, PulseChain
          </p>
        </div>
      </div>
    </div>
  );
}
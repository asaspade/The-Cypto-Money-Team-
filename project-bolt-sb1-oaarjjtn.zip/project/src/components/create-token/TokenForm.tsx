import React, { useState } from 'react';
import TokenBasicInfo from './TokenBasicInfo';
import TokenDistribution from './TokenDistribution';
import TokenVerification from './TokenVerification';
import TokenPurchase from './TokenPurchase';
import TokenPremiumListing from './TokenPremiumListing';
import { PLATFORM_FEES } from '../../config/fees';

export default function TokenForm() {
  const [purchaseAmount, setPurchaseAmount] = useState<string>('');
  const [isPremium, setIsPremium] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
  };

  const baseFee = PLATFORM_FEES.LISTING_FEE;
  const premiumFee = isPremium ? PLATFORM_FEES.PREMIUM_LISTING_FEE : 0;
  const purchaseFee = purchaseAmount ? Number(purchaseAmount) : 0;
  const totalFee = baseFee + premiumFee + purchaseFee;

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <TokenBasicInfo />
      <TokenDistribution />
      <TokenPurchase 
        amount={purchaseAmount}
        onChange={setPurchaseAmount}
      />
      <TokenPremiumListing
        isPremium={isPremium}
        onChange={setIsPremium}
      />
      <TokenVerification />
      
      <div className="stats-card">
        <h3 className="text-xl font-bold mb-4">Summary</h3>
        <div className="space-y-4">
          <div className="flex justify-between py-2 border-b border-primary-500/10">
            <span className="text-gray-400">Base Listing Fee</span>
            <span className="font-medium">${baseFee} USDC</span>
          </div>
          {isPremium && (
            <div className="flex justify-between py-2 border-b border-primary-500/10">
              <span className="text-gray-400">Premium Listing Fee</span>
              <span className="font-medium">${premiumFee} USDC</span>
            </div>
          )}
          {purchaseAmount && (
            <div className="flex justify-between py-2 border-b border-primary-500/10">
              <span className="text-gray-400">Token Purchase</span>
              <span className="font-medium">${purchaseAmount} USDC</span>
            </div>
          )}
          <div className="flex justify-between py-2">
            <span className="font-bold">Total</span>
            <span className="font-bold text-primary-400">${totalFee} USDC</span>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button type="submit" className="btn-primary">
          Create Token
        </button>
      </div>
    </form>
  );
}
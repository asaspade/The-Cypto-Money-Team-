import React from 'react';
import { Rocket } from 'lucide-react';

const steps = [
  'Complete KYC verification',
  'Configure token parameters',
  'Pay listing fee',
  'Submit for review',
  'Launch your token'
];

export default function LaunchSteps() {
  return (
    <div className="stats-card">
      <div className="flex items-center gap-2 mb-6">
        <Rocket className="w-6 h-6 text-primary-500" />
        <h3 className="text-xl font-bold">Launch Steps</h3>
      </div>

      <div className="space-y-4">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-primary-500/20 flex items-center justify-center text-sm text-primary-500 font-medium">
              {index + 1}
            </div>
            <span className="text-gray-400">{step}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
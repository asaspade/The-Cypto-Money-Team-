import React from 'react';
import { Info } from 'lucide-react';

export default function TokenBasicInfo() {
  return (
    <div className="stats-card">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <Info className="w-5 h-5 text-primary-500" />
        <span>Basic Information</span>
      </h2>

      <div className="space-y-6">
        <div>
          <label className="block text-gray-400 mb-2">Token Name</label>
          <input
            type="text"
            placeholder="e.g. Vitruveo Token"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div>
          <label className="block text-gray-400 mb-2">Token Symbol</label>
          <input
            type="text"
            placeholder="e.g. VTRU"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div>
          <label className="block text-gray-400 mb-2">Token Description</label>
          <textarea
            rows={4}
            placeholder="Describe your token and its purpose..."
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>
      </div>
    </div>
  );
}
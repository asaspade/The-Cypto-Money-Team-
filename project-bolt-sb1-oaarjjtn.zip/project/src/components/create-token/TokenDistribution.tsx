import React from 'react';
import { PieChart } from 'lucide-react';

export default function TokenDistribution() {
  return (
    <div className="stats-card">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <PieChart className="w-5 h-5 text-primary-500" />
        <span>Token Distribution</span>
      </h2>

      <div className="space-y-6">
        <div>
          <label className="block text-gray-400 mb-2">Total Supply</label>
          <input
            type="number"
            placeholder="e.g. 1000000"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 mb-2">Presale Allocation (%)</label>
            <input
              type="number"
              placeholder="e.g. 60"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2">Liquidity Allocation (%)</label>
            <input
              type="number"
              placeholder="e.g. 40"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
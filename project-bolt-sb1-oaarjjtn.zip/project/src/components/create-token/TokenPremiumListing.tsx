import React from 'react';
import { Crown, AlertCircle } from 'lucide-react';
import { PLATFORM_FEES } from '../../config/fees';

interface TokenPremiumListingProps {
  isPremium: boolean;
  onChange: (value: boolean) => void;
}

export default function TokenPremiumListing({ isPremium, onChange }: TokenPremiumListingProps) {
  return (
    <div className="stats-card">
      <div className="flex items-center gap-2 mb-6">
        <Crown className="w-6 h-6 text-yellow-500" />
        <h3 className="text-xl font-bold">Premium Listing</h3>
      </div>

      <div className="space-y-4">
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={isPremium}
            onChange={(e) => onChange(e.target.checked)}
            className="mt-1"
          />
          <div>
            <div className="font-medium mb-1">Premium Token Listing</div>
            <p className="text-sm text-gray-400">
              Get featured placement, enhanced visibility, and priority support for your token launch
            </p>
          </div>
        </label>

        {isPremium && (
          <div className="bg-primary-500/10 p-4 rounded-lg border border-primary-500/20">
            <div className="flex items-start gap-2 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 text-primary-500 flex-shrink-0" />
              <div className="space-y-2">
                <p className="text-gray-400">
                  Premium listing requires an additional fee of ${PLATFORM_FEES.PREMIUM_LISTING_FEE} USDC
                </p>
                <ul className="list-disc list-inside text-gray-400 space-y-1">
                  <li>Featured placement on homepage</li>
                  <li>Priority listing in search results</li>
                  <li>Enhanced token profile with detailed metrics</li>
                  <li>24/7 priority support</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
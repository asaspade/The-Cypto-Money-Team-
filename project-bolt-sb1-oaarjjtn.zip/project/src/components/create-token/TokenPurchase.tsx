import React from 'react';
import { DollarSign } from 'lucide-react';

interface TokenPurchaseProps {
  amount: string;
  onChange: (value: string) => void;
}

export default function TokenPurchase({ amount, onChange }: TokenPurchaseProps) {
  return (
    <div className="stats-card">
      <div className="flex items-center gap-2 mb-6">
        <DollarSign className="w-6 h-6 text-primary-500" />
        <h3 className="text-xl font-bold">Token Purchase (Optional)</h3>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-gray-400 mb-2">
            How many tokens would you like to purchase during creation?
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Enter amount in USDC"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>
        <p className="text-sm text-gray-400">
          You can optionally purchase tokens during the creation process. This amount will be added to the listing fee.
        </p>
      </div>
    </div>
  );
}
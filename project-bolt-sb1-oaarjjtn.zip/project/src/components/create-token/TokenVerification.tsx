import React, { useState } from 'react';
import { Shield, Link as LinkIcon } from 'lucide-react';
import FileUpload from '../common/FileUpload';

export default function TokenVerification() {
  const [logo, setLogo] = useState<File | null>(null);
  const [whitepaper, setWhitepaper] = useState<File | null>(null);
  const [whitepaperUrl, setWhitepaperUrl] = useState('');

  return (
    <div className="stats-card">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <Shield className="w-5 h-5 text-primary-500" />
        <span>Verification</span>
      </h2>

      <div className="space-y-6">
        <div>
          <label className="block text-gray-400 mb-2">Project Website</label>
          <input
            type="url"
            placeholder="https://"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 mb-2">Twitter Link</label>
            <input
              type="url"
              placeholder="https://twitter.com/"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2">Discord Link</label>
            <input
              type="url"
              placeholder="https://discord.gg/"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FileUpload
            label="Token Logo"
            accept="image/*"
            helperText="PNG or JPG (max. 2MB)"
            value={logo}
            onChange={setLogo}
          />
          
          <div className="space-y-4">
            <FileUpload
              label="Whitepaper"
              accept=".pdf"
              helperText="PDF format (max. 10MB)"
              value={whitepaper}
              onChange={setWhitepaper}
            />
            
            <div>
              <div className="flex items-center gap-2 text-gray-400 mb-2">
                <LinkIcon className="w-4 h-4" />
                <span>Or provide whitepaper URL</span>
              </div>
              <input
                type="url"
                value={whitepaperUrl}
                onChange={(e) => setWhitepaperUrl(e.target.value)}
                placeholder="https://example.com/whitepaper.pdf"
                className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
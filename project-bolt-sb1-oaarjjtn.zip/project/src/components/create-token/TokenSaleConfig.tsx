import React from 'react';
import { Settings } from 'lucide-react';

export default function TokenSaleConfig() {
  return (
    <div className="stats-card">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <Settings className="w-5 h-5 text-primary-500" />
        <span>Sale Configuration</span>
      </h2>

      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 mb-2">Presale Rate</label>
            <input
              type="number"
              placeholder="Tokens per USDT"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2">Listing Rate</label>
            <input
              type="number"
              placeholder="Tokens per USDT"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 mb-2">Soft Cap (USDT)</label>
            <input
              type="number"
              placeholder="e.g. 50000"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2">Hard Cap (USDT)</label>
            <input
              type="number"
              placeholder="e.g. 100000"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 mb-2">Minimum Buy (USDT)</label>
            <input
              type="number"
              placeholder="e.g. 100"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2">Maximum Buy (USDT)</label>
            <input
              type="number"
              placeholder="e.g. 5000"
              className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
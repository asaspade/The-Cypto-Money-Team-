import React from 'react';
import { Shield, AlertCircle } from 'lucide-react';

export default function LaunchRequirements() {
  return (
    <div className="stats-card">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="w-6 h-6 text-primary-500" />
        <h3 className="text-xl font-bold">Requirements</h3>
      </div>

      <div className="space-y-4">
        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-1 text-primary-500" />
          <div>
            <div className="font-medium mb-1">KYC Verification</div>
            <p className="text-sm text-gray-400">Complete identity verification for project safety</p>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-1 text-primary-500" />
          <div>
            <div className="font-medium mb-1">Smart Contract</div>
            <p className="text-sm text-gray-400">Provide audited contract or use our verified templates</p>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-1 text-primary-500" />
          <div>
            <div className="font-medium mb-1">Project Documentation</div>
            <p className="text-sm text-gray-400">Whitepaper, roadmap, and tokenomics details</p>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 mt-1 text-primary-500" />
          <div>
            <div className="font-medium mb-1">Social Media</div>
            <p className="text-sm text-gray-400">Active community channels and project updates</p>
          </div>
        </div>
      </div>
    </div>
  );
}
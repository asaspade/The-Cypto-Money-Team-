import React from 'react';
import { Wallet, Loader2 } from 'lucide-react';
import { useWallet } from '../../contexts/WalletContext';

interface ConnectWalletButtonProps {
  className?: string;
}

export default function ConnectWalletButton({ className = 'btn-primary' }: ConnectWalletButtonProps) {
  const { account, isConnecting, error, connectWallet, disconnectWallet } = useWallet();

  const handleConnect = async () => {
    if (account) {
      disconnectWallet();
    } else {
      await connectWallet('vitruveo');
    }
  };

  const displayAddress = account 
    ? `${account.slice(0, 6)}...${account.slice(-4)}`
    : 'Connect Wallet';

  return (
    <div className="flex flex-col gap-2">
      {error && (
        <div className="text-sm text-red-500 bg-red-500/10 px-3 py-1 rounded-lg">
          {error}
        </div>
      )}
      <button
        onClick={handleConnect}
        disabled={isConnecting}
        className={`flex items-center gap-2 ${className}`}
      >
        {isConnecting ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Wallet className="w-5 h-5" />
        )}
        {isConnecting ? 'Connecting...' : displayAddress}
      </button>
    </div>
  );
}
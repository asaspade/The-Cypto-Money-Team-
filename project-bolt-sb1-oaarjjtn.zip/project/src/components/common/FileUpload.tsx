import React from 'react';
import { Upload, X } from 'lucide-react';

interface FileUploadProps {
  label: string;
  accept?: string;
  helperText?: string;
  value?: File | null;
  onChange: (file: File | null) => void;
}

export default function FileUpload({ label, accept, helperText, value, onChange }: FileUploadProps) {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onChange(file);
  };

  const clearFile = () => {
    onChange(null);
  };

  return (
    <div>
      <label className="block text-gray-400 mb-2">{label}</label>
      <div className="relative">
        {!value ? (
          <div className="w-full bg-gray-800/50 border-2 border-dashed border-gray-700 rounded-lg p-4 hover:border-primary-500 transition-colors">
            <input
              type="file"
              accept={accept}
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="flex flex-col items-center justify-center gap-2">
              <Upload className="w-6 h-6 text-primary-500" />
              <p className="text-sm text-gray-400">
                Drag and drop or click to upload
              </p>
              {helperText && (
                <p className="text-xs text-gray-500">{helperText}</p>
              )}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between bg-gray-800/50 border border-primary-500/50 rounded-lg p-4">
            <span className="text-primary-400 truncate">{value.name}</span>
            <button
              onClick={clearFile}
              className="p-1 hover:bg-primary-500/20 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-primary-500" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { DollarSign } from 'lucide-react';

export default function TokenPrice() {
  return (
    <div className="fixed bottom-4 right-4 bg-gray-900/90 backdrop-blur-sm border border-primary-500/20 rounded-lg p-3 shadow-lg">
      <div className="flex items-center gap-2">
        <div className="bg-primary-500/20 p-2 rounded-lg">
          <DollarSign className="w-4 h-4 text-primary-500" />
        </div>
        <div>
          <div className="text-xs text-gray-400">VTRU Price</div>
          <div className="font-bold text-primary-400">
            <a 
              href="https://etherscan.io/token/0xb08504d245713ca9692c8fa605e76a0a11ed4955"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-primary-500 transition-colors"
            >
              View on Etherscan
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
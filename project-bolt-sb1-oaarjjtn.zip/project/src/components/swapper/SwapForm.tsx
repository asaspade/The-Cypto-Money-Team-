import React, { useState } from 'react';
import { ArrowDown } from 'lucide-react';

export default function SwapForm() {
  const [amount, setAmount] = useState('');
  const vtruAmount = Number(amount) / 0.2045;

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-gray-400 mb-2">You Pay (USDC)</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter USDC amount"
          className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-3 px-4 focus:outline-none focus:border-primary-500"
        />
      </div>

      <div className="flex justify-center">
        <div className="w-10 h-10 rounded-full bg-primary-500/20 flex items-center justify-center">
          <ArrowDown className="w-5 h-5 text-primary-500" />
        </div>
      </div>

      <div>
        <label className="block text-gray-400 mb-2">You Receive (VTRU)</label>
        <input
          type="number"
          value={vtruAmount || ''}
          disabled
          className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-3 px-4 opacity-75 cursor-not-allowed"
        />
        <div className="text-sm text-gray-400 mt-2">
          1 VTRU = $0.2045
        </div>
      </div>

      <button className="btn-primary w-full">Buy VTRU</button>
    </div>
  );
}
import React, { useState } from 'react';
import { ArrowDownUp } from 'lucide-react';

export default function WrapForm() {
  const [amount, setAmount] = useState('');
  const [isWrapping, setIsWrapping] = useState(true);

  return (
    <div className="space-y-6">
      <div className="flex justify-center mb-2">
        <button
          onClick={() => setIsWrapping(!isWrapping)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-500/20 text-primary-400"
        >
          <ArrowDownUp className="w-4 h-4" />
          {isWrapping ? 'Wrap VTRU' : 'Unwrap VTRU'}
        </button>
      </div>

      <div>
        <label className="block text-gray-400 mb-2">
          Amount ({isWrapping ? 'VTRU' : 'wVTRU'})
        </label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder={`Enter ${isWrapping ? 'VTRU' : 'wVTRU'} amount`}
          className="w-full bg-gray-800/50 border border-gray-700 rounded-lg py-3 px-4 focus:outline-none focus:border-primary-500"
        />
      </div>

      <button className="btn-primary w-full">
        {isWrapping ? 'Wrap VTRU' : 'Unwrap VTRU'}
      </button>
    </div>
  );
}
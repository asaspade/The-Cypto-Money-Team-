import React, { useState } from 'react';
import { ArrowDownUp, ArrowRightLeft, ArrowLeftRight } from 'lucide-react';
import BridgeForm from './BridgeForm';
import SwapForm from './SwapForm';
import WrapForm from './WrapForm';

const tabs = [
  { id: 'bridge', label: 'Bridge USDC', icon: ArrowLeftRight },
  { id: 'swap', label: 'Buy VTRU', icon: ArrowRightLeft },
  { id: 'wrap', label: 'Wrap/Unwrap', icon: ArrowDownUp },
] as const;

type TabId = typeof tabs[number]['id'];

export default function SwapperTabs() {
  const [activeTab, setActiveTab] = useState<TabId>('bridge');

  return (
    <div className="stats-card">
      <div className="flex gap-2 mb-6">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              activeTab === id
                ? 'bg-primary-500/20 text-primary-400'
                : 'text-gray-400 hover:bg-primary-500/10'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'bridge' && <BridgeForm />}
      {activeTab === 'swap' && <SwapForm />}
      {activeTab === 'wrap' && <WrapForm />}
    </div>
  );
}
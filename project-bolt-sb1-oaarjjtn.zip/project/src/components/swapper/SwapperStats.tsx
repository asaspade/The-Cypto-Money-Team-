import React from 'react';
import { DollarSign, ArrowRightLeft, Users } from 'lucide-react';

export default function SwapperStats() {
  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="stats-card">
        <div className="flex items-center gap-3">
          <DollarSign className="w-5 h-5 text-primary-500" />
          <div>
            <div className="text-sm text-gray-400">VTRU Price</div>
            <div className="font-bold">$0.2045</div>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3">
          <ArrowRightLeft className="w-5 h-5 text-primary-500" />
          <div>
            <div className="text-sm text-gray-400">24h Volume</div>
            <div className="font-bold">$1.2M</div>
          </div>
        </div>
      </div>

      <div className="stats-card">
        <div className="flex items-center gap-3">
          <Users className="w-5 h-5 text-primary-500" />
          <div>
            <div className="text-sm text-gray-400">Holders</div>
            <div className="font-bold">12.5K</div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import Button from './common/Button';

export default function WalletConnect() {
  const { account, isConnecting, error, connectWallet, disconnectWallet } = useWallet();

  const handleConnect = async () => {
    if (account) {
      disconnectWallet();
    } else {
      await connectWallet('vitruveo');
    }
  };

  const displayAddress = account 
    ? `${account.slice(0, 6)}...${account.slice(-4)}`
    : 'Connect Wallet';

  return (
    <div className="flex flex-col gap-2">
      {error && (
        <div className="flex items-center gap-2 bg-red-500/10 text-red-500 px-3 py-1.5 rounded-lg text-sm">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}
      <Button
        variant={account ? 'secondary' : 'primary'}
        isLoading={isConnecting}
        onClick={handleConnect}
      >
        {isConnecting ? 'Connecting...' : displayAddress}
      </Button>
    </div>
  );
}
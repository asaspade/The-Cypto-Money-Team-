import React, { useEffect, useRef } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TokenPrice {
  symbol: string;
  price: string;
  change: string;
  isPositive: boolean;
}

const tokenPrices: TokenPrice[] = [
  { symbol: 'MVT', price: '$0.05', change: '+12.5%', isPositive: true },
  { symbol: 'DFP', price: '$0.08', change: '-3.2%', isPositive: false },
  { symbol: 'GFT', price: '$0.03', change: '+8.7%', isPositive: true },
  { symbol: 'VTRU', price: '$0.15', change: '+15.3%', isPositive: true },
  { symbol: 'BTC', price: '$65,420', change: '+2.1%', isPositive: true },
  { symbol: 'ETH', price: '$3,480', change: '-1.2%', isPositive: false },
];

export default function TokenTicker() {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    const scroll = () => {
      if (scrollContainer.scrollLeft >= scrollContainer.scrollWidth / 2) {
        scrollContainer.scrollLeft = 0;
      } else {
        scrollContainer.scrollLeft += 1;
      }
    };

    const intervalId = setInterval(scroll, 30);
    return () => clearInterval(intervalId);
  }, []);

  const tickerContent = [...tokenPrices, ...tokenPrices]; // Duplicate for seamless loop

  return (
    <div className="bg-gray-900/80 backdrop-blur-sm border-b border-primary-500/20">
      <div 
        ref={scrollRef}
        className="max-w-full overflow-hidden whitespace-nowrap py-2"
      >
        <div className="inline-block animate-scroll">
          {tickerContent.map((token, index) => (
            <div 
              key={`${token.symbol}-${index}`}
              className="inline-flex items-center mx-6"
            >
              <span className="font-medium text-primary-400">{token.symbol}</span>
              <span className="mx-2 text-gray-400">{token.price}</span>
              <span 
                className={`flex items-center gap-1 ${
                  token.isPositive ? 'text-green-500' : 'text-red-500'
                }`}
              >
                {token.isPositive ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                {token.change}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Clock, Users, Rocket } from 'lucide-react';

interface OpportunityCardProps {
  title: string;
  description: string;
  apy: string;
  lockPeriod: string;
  participants: number;
  totalStaked: string;
}

export default function OpportunityCard({
  title,
  description,
  apy,
  lockPeriod,
  participants,
  totalStaked,
}: OpportunityCardProps) {
  return (
    <div className="stats-card hover:scale-[1.02]">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold text-primary-400">{title}</h3>
          <p className="text-gray-400 mt-2">{description}</p>
        </div>
        <div className="tag">
          <span>{apy} APY</span>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 mt-6">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 icon-primary" />
          <span className="text-sm text-gray-300">{lockPeriod}</span>
        </div>
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 icon-primary" />
          <span className="text-sm text-gray-300">{participants}</span>
        </div>
        <div className="flex items-center gap-2">
          <Rocket className="w-4 h-4 icon-primary" />
          <span className="text-sm text-gray-300">{totalStaked}</span>
        </div>
      </div>
    </div>
  );
}
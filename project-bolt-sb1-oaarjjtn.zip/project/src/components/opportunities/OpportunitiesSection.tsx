import React from 'react';
import { Gem } from 'lucide-react';
import OpportunityCard from './OpportunityCard';
import { opportunities } from '../../data/opportunitiesData';

export default function OpportunitiesSection() {
  return (
    <div className="mt-12">
      <div className="flex items-center gap-3 mb-6">
        <Gem className="w-6 h-6 icon-primary" />
        <h2 className="section-title">Opportunities</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {opportunities.map((opportunity) => (
          <OpportunityCard key={opportunity.id} {...opportunity} />
        ))}
      </div>
    </div>
  );
}
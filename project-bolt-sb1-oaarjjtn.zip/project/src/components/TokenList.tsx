{/* Add after StatsOverview */}
<div className="mb-12">
  <PremiumTokenSlider />
</div>
import React, { useState, useRef, useEffect } from 'react';
import { Search, Bell, Settings, Rocket, Plus, Menu as MenuIcon, X, Crown, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { routes } from '../utils/navigation';
import Button from './common/Button';
import KYCButton from './KYCButton';
import WalletConnect from './WalletConnect';
import AdminLoginModal from './admin/AdminLoginModal';
import { useAdmin } from '../contexts/AdminContext';
import useClickOutside from '../hooks/useClickOutside';

export default function Header() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { isAdmin, logout } = useAdmin();
  
  const settingsRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useClickOutside(settingsRef, () => setIsSettingsOpen(false));
  useClickOutside(menuRef, () => setIsMenuOpen(false));

  return (
    <header className="border-b border-primary-500/20 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Rocket className="w-8 h-8 text-primary-500" />
            <h1 className="text-xl md:text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
              Crypto Launcher
            </h1>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search projects..."
                className="bg-gray-900/50 border border-gray-800 rounded-lg py-2 px-4 pl-10 focus:outline-none focus:border-primary-500 w-64"
              />
              <Search className="w-5 h-5 text-primary-400 absolute left-3 top-2.5" />
            </div>

            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors">
                <Bell className="w-5 h-5 text-primary-400" />
              </button>

              <div className="relative" ref={settingsRef}>
                <button 
                  onClick={() => isAdmin ? setIsSettingsOpen(!isSettingsOpen) : setIsAdminModalOpen(true)}
                  className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors group relative"
                >
                  <Settings className="w-5 h-5 text-primary-400 group-hover:rotate-45 transition-transform" />
                </button>
                {isAdmin && isSettingsOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-gray-900 border border-primary-500/20 rounded-lg shadow-xl py-1 z-50">
                    <div className="px-4 py-2 border-b border-primary-500/10">
                      <div className="text-sm font-medium">Admin Panel</div>
                      <div className="text-xs text-gray-400">Manage platform</div>
                    </div>
                    <button 
                      onClick={logout}
                      className="flex items-center gap-2 px-4 py-2 text-red-400 hover:bg-red-500/10 w-full text-left text-sm"
                    >
                      <LogOut className="w-4 h-4" />
                      Logout
                    </button>
                  </div>
                )}
              </div>
            </div>

            <KYCButton />

            <Button 
              onClick={() => navigate(routes.createToken)}
              variant="primary"
              leftIcon={<Plus className="w-5 h-5" />}
            >
              Create Token
            </Button>

            <WalletConnect />
          </div>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 hover:bg-primary-500/20 rounded-lg transition-colors"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6 text-primary-400" />
            ) : (
              <MenuIcon className="w-6 h-6 text-primary-400" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div 
            ref={menuRef}
            className="lg:hidden mt-4 py-4 border-t border-primary-500/20 space-y-4"
          >
            <div className="relative">
              <input
                type="text"
                placeholder="Search projects..."
                className="w-full bg-gray-900/50 border border-gray-800 rounded-lg py-2 px-4 pl-10 focus:outline-none focus:border-primary-500"
              />
              <Search className="w-5 h-5 text-primary-400 absolute left-3 top-2.5" />
            </div>
            
            <div className="flex justify-between">
              <button className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors">
                <Bell className="w-5 h-5 text-primary-400" />
              </button>
              <button 
                onClick={() => isAdmin ? setIsSettingsOpen(!isSettingsOpen) : setIsAdminModalOpen(true)}
                className="p-2 hover:bg-primary-500/20 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5 text-primary-400" />
              </button>
            </div>
            
            <div className="flex flex-col gap-3">
              <KYCButton />
              
              <Button 
                onClick={() => {
                  navigate(routes.createToken);
                  setIsMenuOpen(false);
                }}
                variant="primary"
                leftIcon={<Plus className="w-5 h-5" />}
                fullWidth
              >
                Create Token
              </Button>
              
              <WalletConnect />
            </div>
          </div>
        )}
      </div>

      <AdminLoginModal 
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </header>
  );
}
import React from 'react';
import { Users, Timer, Wallet, DollarSign } from 'lucide-react';

interface TokenStatsProps {
  price: string;
  totalRaised: string;
  participants: number;
  timeLeft: string;
}

export default function TokenStats({ price, totalRaised, participants, timeLeft }: TokenStatsProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <DollarSign className="w-4 h-4" />
          <span>Price</span>
        </div>
        <div className="text-xl font-bold">{price}</div>
      </div>
      
      <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <Wallet className="w-4 h-4" />
          <span>Total Raised</span>
        </div>
        <div className="text-xl font-bold">{totalRaised}</div>
      </div>
      
      <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <Users className="w-4 h-4" />
          <span>Participants</span>
        </div>
        <div className="text-xl font-bold">{participants}</div>
      </div>
      
      <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <Timer className="w-4 h-4" />
          <span>Time Left</span>
        </div>
        <div className="text-xl font-bold">{timeLeft}</div>
      </div>
    </div>
  );
}
import React from 'react';
import { BarChart2, Coins } from 'lucide-react';

interface TokenMetricsProps {
  marketCap: string;
  totalSupply: string;
  network: string;
}

export default function TokenMetrics({ marketCap, totalSupply, network }: TokenMetricsProps) {
  return (
    <div className="stats-card">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <BarChart2 className="w-5 h-5 text-primary-500" />
        Token Metrics
      </h3>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center py-3 border-b border-primary-500/10">
          <span className="text-gray-400">Market Cap</span>
          <span className="font-semibold text-primary-400">{marketCap}</span>
        </div>
        <div className="flex justify-between items-center py-3 border-b border-primary-500/10">
          <span className="text-gray-400">Total Supply</span>
          <span className="font-semibold text-primary-400">{totalSupply}</span>
        </div>
        <div className="flex justify-between items-center py-3">
          <span className="text-gray-400">Network</span>
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-primary-500" />
            <span className="font-semibold text-primary-400">{network}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
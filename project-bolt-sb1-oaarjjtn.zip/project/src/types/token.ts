export interface TokenHolding {
  id: string;
  name: string;
  symbol: string;
  chainId: string;
  balance: string;
  value: number;
  priceChange24h: number;
  imageUrl?: string;
}

// ... rest of the existing types
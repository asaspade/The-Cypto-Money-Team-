import { useState, useCallback, useMemo } from 'react';
import { supportedChains } from '../config/chains';

export function useBlockchainFilter<T extends { chainId: string }>(items: T[]) {
  const [selectedChain, setSelectedChain] = useState('all');

  const filteredItems = useMemo(() => {
    if (selectedChain === 'all') return items;
    return items.filter(item => item.chainId === selectedChain);
  }, [items, selectedChain]);

  const handleChainSelect = useCallback((chainId: string) => {
    setSelectedChain(chainId);
  }, []);

  return {
    selectedChain,
    filteredItems,
    handleChainSelect,
  };
}
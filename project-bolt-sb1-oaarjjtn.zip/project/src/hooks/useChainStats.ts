import { useState, useEffect } from 'react';
import { supportedChains } from '../config/chains';
import { 
  featuredTokens 
} from '../data/mockTokenData';
import { 
  followedTokens 
} from '../data/followedTokens';
import { 
  myTokens 
} from '../data/myTokens';
import { 
  staticTokens 
} from '../data/staticTokens';
import { 
  liveTokens 
} from '../data/liveTokens';

interface ChainStat {
  chainId: string;
  name: string;
  tokenCount: number;
}

export function useChainStats() {
  const [chainStats, setChainStats] = useState<ChainStat[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const calculateStats = () => {
      // Combine all tokens
      const allTokens = [
        ...featuredTokens,
        ...followedTokens,
        ...myTokens,
        ...staticTokens,
        ...liveTokens
      ];

      // Count tokens per chain
      const chainCounts = allTokens.reduce((acc, token) => {
        acc[token.chainId] = (acc[token.chainId] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      // Create stats array
      const stats = supportedChains.map(chain => ({
        chainId: chain.id,
        name: chain.name,
        tokenCount: chainCounts[chain.id] || 0
      }));

      // Sort by token count descending
      stats.sort((a, b) => b.tokenCount - a.tokenCount);

      setChainStats(stats);
      setIsLoading(false);
    };

    // Simulate API delay
    setTimeout(calculateStats, 1000);
  }, []);

  return { chainStats, isLoading };
}
import { useState, useCallback } from 'react';

export function usePhantom() {
  const [publicKey, setPublicKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const connectPhantom = useCallback(async () => {
    try {
      if (!window.solana?.isPhantom) {
        window.open('https://phantom.app/', '_blank');
        throw new Error('Please install Phantom wallet');
      }

      const response = await window.solana.connect();
      setPublicKey(response.publicKey.toString());
      setError(null);
    } catch (err: any) {
      setError(err.message);
      setPublicKey(null);
    }
  }, []);

  const disconnectPhantom = useCallback(async () => {
    if (window.solana) {
      await window.solana.disconnect();
      setPublicKey(null);
    }
  }, []);

  return {
    publicKey,
    error,
    connectPhantom,
    disconnectPhantom,
    isPhantomInstalled: window.solana?.isPhantom
  };
}
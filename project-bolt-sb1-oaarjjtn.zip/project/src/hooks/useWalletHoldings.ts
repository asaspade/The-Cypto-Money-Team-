import { useState, useEffect } from 'react';
import { TokenHolding } from '../types/token';
import { tokenImages } from '../data/tokenData';

const mockHoldings: TokenHolding[] = [
  {
    id: '1',
    name: 'Vitruveo',
    symbol: 'VTRU',
    chainId: 'vitruveo',
    balance: '10000',
    value: 5000,
    priceChange24h: 12.5,
    imageUrl: tokenImages.VTRU
  },
  {
    id: '2',
    name: 'PulseX',
    symbol: 'PLSX',
    chainId: 'pulsechain',
    balance: '50000',
    value: 2500,
    priceChange24h: -3.2,
    imageUrl: tokenImages.PLSX
  },
  {
    id: '3',
    name: 'Pulse',
    symbol: 'PLS',
    chainId: 'pulsechain',
    balance: '25000',
    value: 1250,
    priceChange24h: 5.8,
    imageUrl: tokenImages.PULSE
  }
];

export function useWalletHoldings() {
  const [holdings, setHoldings] = useState<TokenHolding[]>([]);
  const [selectedChain, setSelectedChain] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchHoldings = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setHoldings(mockHoldings);
      } catch (error) {
        console.error('Error fetching holdings:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHoldings();
  }, []);

  const filteredHoldings = selectedChain === 'all'
    ? holdings
    : holdings.filter(token => token.chainId === selectedChain);

  const totalValue = holdings.reduce((sum, token) => sum + token.value, 0);

  return {
    holdings: filteredHoldings,
    totalValue,
    isLoading,
    selectedChain,
    handleChainSelect: setSelectedChain
  };
}
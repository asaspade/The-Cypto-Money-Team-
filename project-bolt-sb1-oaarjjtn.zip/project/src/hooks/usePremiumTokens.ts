import { useState, useEffect } from 'react';
import { premiumTokens } from '../data/premiumTokens';

export function usePremiumTokens() {
  const [tokens, setTokens] = useState(premiumTokens);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadTokens = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setTokens(premiumTokens);
      } catch (error) {
        console.error('Error loading premium tokens:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadTokens();

    // Auto-refresh every 30 seconds
    const interval = setInterval(loadTokens, 30000);
    return () => clearInterval(interval);
  }, []);

  return { tokens, isLoading };
}
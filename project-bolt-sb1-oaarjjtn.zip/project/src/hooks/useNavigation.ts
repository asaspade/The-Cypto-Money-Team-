import { useNavigate } from 'react-router-dom';
import { routes } from '../routes';

export function useAppNavigation() {
  const navigate = useNavigate();

  return {
    goToHome: () => navigate(routes.home),
    goToToken: (id: string) => navigate(routes.tokenDetail(id)),
  };
}
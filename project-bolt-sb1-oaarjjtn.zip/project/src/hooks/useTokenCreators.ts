import { useState, useEffect } from 'react';
import { TokenCreator } from '../types/token';
import { mockCreators } from '../data/mockCreators';

export function useTokenCreators() {
  const [creators, setCreators] = useState<TokenCreator[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCreators = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setCreators(mockCreators);
      } catch (error) {
        console.error('Error fetching token creators:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCreators();
  }, []);

  return { creators, isLoading };
}
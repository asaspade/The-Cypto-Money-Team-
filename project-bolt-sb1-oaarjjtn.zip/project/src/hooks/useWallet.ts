import { useState, useCallback } from 'react';
import { supportedChains } from '../config/chains';
import type { Chain } from '../types/chain';

interface WalletState {
  account: string | null;
  chain: Chain | null;
  isConnecting: boolean;
  error: string | null;
}

export function useWallet() {
  const [state, setState] = useState<WalletState>({
    account: null,
    chain: null,
    isConnecting: false,
    error: null,
  });

  const connectWallet = useCallback(async (chainId: string) => {
    setState(prev => ({ ...prev, isConnecting: true, error: null }));
    
    const selectedChain = supportedChains.find(chain => chain.id === chainId);
    if (!selectedChain) {
      setState(prev => ({ 
        ...prev, 
        isConnecting: false, 
        error: 'Unsupported blockchain' 
      }));
      return;
    }

    try {
      if (typeof window.ethereum !== 'undefined') {
        const accounts = await window.ethereum.request({ 
          method: 'eth_requestAccounts' 
        });

        // Switch network if needed
        if (chainId === 'vitruveo') {
          await switchToVitruveo();
        } else if (chainId === 'bnb') {
          await switchToBNBChain();
        }

        setState(prev => ({
          ...prev,
          account: accounts[0],
          chain: selectedChain,
          isConnecting: false,
          error: null,
        }));
      } else {
        window.open('https://metamask.io/download.html', '_blank');
        setState(prev => ({
          ...prev,
          isConnecting: false,
          error: 'Please install MetaMask',
        }));
      }
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        isConnecting: false,
        error: error.code === 4001 ? 'Please connect your wallet' : 'Failed to connect wallet',
      }));
    }
  }, []);

  const switchToVitruveo = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: '0x1', // Replace with actual Vitruveo chainId
          chainName: 'Vitruveo Network',
          nativeCurrency: {
            name: 'VTRU',
            symbol: 'VTRU',
            decimals: 18,
          },
          rpcUrls: ['https://rpc.vitruveo.xyz'],
          blockExplorerUrls: ['https://scan.vitruveo.xyz'],
        }],
      });
    } catch (error) {
      console.error('Failed to switch to Vitruveo network:', error);
      throw error;
    }
  };

  const switchToBNBChain = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: '0x38',
          chainName: 'BNB Chain',
          nativeCurrency: {
            name: 'BNB',
            symbol: 'BNB',
            decimals: 18,
          },
          rpcUrls: ['https://bsc-dataseed.binance.org'],
          blockExplorerUrls: ['https://bscscan.com'],
        }],
      });
    } catch (error) {
      console.error('Failed to switch to BNB Chain:', error);
      throw error;
    }
  };

  return {
    ...state,
    connectWallet,
  };
}
import { useState, useEffect, useCallback } from 'react';
import { TokenInfo } from '../types/token';
import { fetchTopTokens } from '../services/vitruveoExplorer';

export function useVitruveoTokens() {
  const [tokens, setTokens] = useState<TokenInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadTokens = useCallback(async () => {
    try {
      setIsLoading(true);
      const data = await fetchTopTokens();
      setTokens(data);
      setError(null);
    } catch (err) {
      console.error('Error loading tokens:', err);
      setError('Failed to load token data');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTokens();
    
    // Refresh data every 30 seconds
    const interval = setInterval(loadTokens, 30000);
    
    return () => {
      clearInterval(interval);
    };
  }, [loadTokens]);

  // Expose a manual refresh function
  const refresh = () => {
    if (!isLoading) {
      loadTokens();
    }
  };

  return { tokens, isLoading, error, refresh };
}
import { useState, useCallback } from 'react';
import { supportedChains } from '../config/chains';
import type { Chain } from '../types/chain';

export function useMetaMask() {
  const [account, setAccount] = useState<string | null>(null);
  const [chain, setChain] = useState<Chain | null>(null);
  const [error, setError] = useState<string | null>(null);

  const connectMetaMask = useCallback(async (chainId: string) => {
    const selectedChain = supportedChains.find(c => c.id === chainId && c.type === 'evm');
    if (!selectedChain) {
      setError('Unsupported blockchain');
      return;
    }

    try {
      if (typeof window.ethereum === 'undefined') {
        window.open('https://metamask.io/download.html', '_blank');
        throw new Error('Please install MetaMask');
      }

      const accounts = await window.ethereum.request({ 
        method: 'eth_requestAccounts' 
      });

      // Switch network based on chain
      switch (chainId) {
        case 'vitruveo':
          await switchToVitruveo();
          break;
        case 'pulsechain':
          await switchToPulseChain();
          break;
        case 'bnb':
          await switchToBNBChain();
          break;
      }

      setAccount(accounts[0]);
      setChain(selectedChain);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      setAccount(null);
      setChain(null);
    }
  }, []);

  const switchToPulseChain = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: '0x171', // 369 in hex
          chainName: 'PulseChain',
          nativeCurrency: {
            name: 'PLS',
            symbol: 'PLS',
            decimals: 18,
          },
          rpcUrls: ['https://rpc.pulsechain.com'],
          blockExplorerUrls: ['https://scan.pulsechain.com'],
        }],
      });
    } catch (error) {
      console.error('Failed to switch to PulseChain:', error);
      throw error;
    }
  };

  // ... rest of the existing code (switchToVitruveo, switchToBNBChain, etc.)

  return {
    account,
    chain,
    error,
    connectMetaMask,
  };
}
export const PLATFORM_FEES = {
  LISTING_FEE: 25, // Base listing fee in USDC
  PREMIUM_LISTING_FEE: 50, // Premium listing fee in USDC
  TRANSACTION_FEE_PERCENT: 1,
  FEE_WALLET: '0xb46F5E6B79792F87fb5Dbc3D805627B077c7fbb2'
} as const;
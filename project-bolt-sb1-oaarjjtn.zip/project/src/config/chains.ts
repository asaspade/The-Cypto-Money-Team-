export const supportedChains = [
  {
    id: 'vitruveo',
    name: 'Vitruveo',
    type: 'evm',
    nativeCurrency: {
      name: 'VTRU',
      symbol: 'VTRU',
      decimals: 18,
    },
    rpcUrls: ['https://rpc.vitruveo.xyz'],
    blockExplorers: {
      default: { name: 'VitruveoScan', url: 'https://scan.vitruveo.xyz' },
    },
    testnet: false,
  },
  {
    id: 'pulsechain',
    name: 'PulseChain',
    type: 'evm',
    nativeCurrency: {
      name: 'PLS',
      symbol: 'PLS',
      decimals: 18,
    },
    rpcUrls: ['https://rpc.pulsechain.com'],
    blockExplorers: {
      default: { name: 'PulseScan', url: 'https://scan.pulsechain.com' },
    },
    chainId: '0x171', // 369 in decimal
    testnet: false,
  },
  {
    id: 'solana',
    name: 'Solana',
    type: 'solana',
    nativeCurrency: {
      name: 'SOL',
      symbol: 'SOL',
      decimals: 9,
    },
    rpcUrls: ['https://api.mainnet-beta.solana.com'],
    blockExplorers: {
      default: { name: 'Solana Explorer', url: 'https://explorer.solana.com' },
    },
    testnet: false,
  },
  {
    id: 'bnb',
    name: 'BNB Chain',
    type: 'evm',
    nativeCurrency: {
      name: 'BNB',
      symbol: 'BNB',
      decimals: 18,
    },
    rpcUrls: ['https://bsc-dataseed.binance.org'],
    blockExplorers: {
      default: { name: 'BscScan', url: 'https://bscscan.com' },
    },
    testnet: false,
  },
] as const;
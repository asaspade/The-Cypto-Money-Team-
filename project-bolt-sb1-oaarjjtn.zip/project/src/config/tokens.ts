export const TOKENS = {
  VTRU: {
    symbol: 'VTRU',
    name: 'Vitruveo',
    decimals: 18,
    address: '0x8BEFf5EC6A15F499EfA446b1eb9F1c74dcFe9495',
    price: 0.2045,
    chainId: 'vitruveo'
  },
  WVTRU: {
    symbol: 'wVTRU',
    name: 'Wrapped VTRU',
    decimals: 18,
    address: '0x1234567890abcdef1234567890abcdef12345678',
    price: 0.2045,
    chainId: 'vitruveo'
  },
  USDC: {
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    address: '0xabcdef1234567890abcdef1234567890abcdef12',
    price: 1,
    chainId: 'bnb'
  }
} as const;
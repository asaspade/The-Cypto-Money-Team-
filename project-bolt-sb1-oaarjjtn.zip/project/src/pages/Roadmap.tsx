import React from 'react';
import { Milestone } from 'lucide-react';
import RoadmapIntro from '../components/roadmap/RoadmapIntro';
import RoadmapPhases from '../components/roadmap/RoadmapPhases';
import RoadmapFeatures from '../components/roadmap/RoadmapFeatures';
import RoadmapMetrics from '../components/roadmap/RoadmapMetrics';

export default function Roadmap() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <Milestone className="w-16 h-16 text-primary-500 mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Platform Roadmap
        </h1>
      </div>

      <div className="space-y-16">
        <RoadmapIntro />
        <RoadmapPhases />
        <RoadmapFeatures />
        <RoadmapMetrics />
      </div>
    </div>
  );
}
import React from 'react';
import { Clock } from 'lucide-react';
import TokenFilters from '../components/TokenFilters';
import TokenCard from '../components/TokenCard';
import { staticTokens } from '../data/staticTokens';
import { useBlockchainFilter } from '../hooks/useBlockchainFilter';
import BlockchainTabs from '../components/blockchain/BlockchainTabs';

export default function Static() {
  const { selectedChain, filteredItems, handleChainSelect } = useBlockchainFilter(staticTokens);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <Clock className="w-6 h-6 text-primary-500" />
        <h2 className="text-2xl font-bold">Static Tokens</h2>
      </div>
      
      <BlockchainTabs 
        selectedChain={selectedChain}
        onSelect={handleChainSelect}
      />
      <TokenFilters />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((token) => (
          <TokenCard key={token.id} {...token} />
        ))}
      </div>
    </div>
  );
}
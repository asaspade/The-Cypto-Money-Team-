import React from 'react';
import { Users, Shield, Target, Globe } from 'lucide-react';

const stats = [
  { icon: Users, value: '50K+', label: 'Users' },
  { icon: Shield, value: '100%', label: 'Secure' },
  { icon: Target, value: '85+', label: 'Launches' },
  { icon: Globe, value: '24/7', label: 'Support' },
];

export default function AboutUs() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          About Crypto Launcher
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Building the future of token launches with security, transparency, and innovation.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="stats-card text-center">
              <Icon className="w-8 h-8 text-primary-500 mx-auto mb-4" />
              <div className="text-3xl font-bold mb-2">{stat.value}</div>
              <div className="text-gray-400">{stat.label}</div>
            </div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-16">
        <div className="stats-card">
          <h2 className="text-2xl font-bold mb-6">Our Mission</h2>
          <p className="text-gray-400">
            To democratize token launches by providing a secure, transparent, and efficient platform
            that empowers projects and protects investors. We're committed to fostering innovation
            while maintaining the highest standards of security and compliance.
          </p>
        </div>

        <div className="stats-card">
          <h2 className="text-2xl font-bold mb-6">Our Vision</h2>
          <p className="text-gray-400">
            To become the world's leading token launch platform, setting the standard for security,
            transparency, and innovation in the cryptocurrency space. We envision a future where
            token launches are accessible, secure, and successful for all participants.
          </p>
        </div>
      </div>

      <div className="stats-card">
        <h2 className="text-2xl font-bold mb-6">The Team</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { name: 'Alex Thompson', role: 'CEO & Founder', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150' },
            { name: 'Sarah Chen', role: 'CTO', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150' },
            { name: 'Michael Rodriguez', role: 'Head of Security', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150' },
          ].map((member, index) => (
            <div key={index} className="text-center">
              <img
                src={member.image}
                alt={member.name}
                className="w-32 h-32 rounded-full mx-auto mb-4 border-2 border-primary-500"
              />
              <h3 className="text-xl font-bold mb-2">{member.name}</h3>
              <p className="text-gray-400">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
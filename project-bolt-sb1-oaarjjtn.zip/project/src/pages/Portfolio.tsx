import React from 'react';
import { Wallet, PieChart, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { useWalletHoldings } from '../hooks/useWalletHoldings';
import BlockchainTabs from '../components/blockchain/BlockchainTabs';
import PortfolioStats from '../components/portfolio/PortfolioStats';
import PortfolioChart from '../components/portfolio/PortfolioChart';
import TokenHoldingCard from '../components/portfolio/TokenHoldingCard';
import ConnectWalletButton from '../components/common/ConnectWalletButton';

export default function Portfolio() {
  const { 
    holdings,
    totalValue,
    isLoading,
    selectedChain,
    handleChainSelect
  } = useWalletHoldings();

  if (!holdings.length) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center">
          <Wallet className="w-16 h-16 text-primary-500 mx-auto mb-6" />
          <h1 className="text-3xl font-bold mb-4">Connect Your Wallet</h1>
          <p className="text-gray-400 mb-8">
            Connect your wallet to view your token holdings and portfolio statistics
          </p>
          <ConnectWalletButton />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <PieChart className="w-6 h-6 text-primary-500" />
        <h1 className="text-2xl font-bold">My Portfolio</h1>
      </div>

      <PortfolioStats totalValue={totalValue} />
      
      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        <div className="lg:col-span-2">
          <PortfolioChart />
        </div>
        <div>
          <div className="stats-card h-full">
            <h3 className="text-xl font-bold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {i % 2 === 0 ? (
                      <ArrowUpRight className="w-4 h-4 text-green-500" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4 text-red-500" />
                    )}
                    <div>
                      <div className="font-medium">
                        {i % 2 === 0 ? 'Bought' : 'Sold'} VTRU
                      </div>
                      <div className="text-sm text-gray-400">2 hours ago</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">1,000 VTRU</div>
                    <div className="text-sm text-gray-400">$500.00</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <BlockchainTabs 
        selectedChain={selectedChain}
        onSelect={handleChainSelect}
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {holdings.map((token) => (
          <TokenHoldingCard key={token.id} {...token} />
        ))}
      </div>
    </div>
  );
}
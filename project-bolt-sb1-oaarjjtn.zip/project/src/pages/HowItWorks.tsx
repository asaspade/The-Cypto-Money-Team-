import React from 'react';
import { Lightbulb, Shield, Rocket, Target } from 'lucide-react';
import FeeStructure from '../components/how-it-works/FeeStructure';
import LaunchInstructions from '../components/how-it-works/LaunchInstructions';

const steps = [
  {
    icon: Lightbulb,
    title: 'Create Your Token',
    description: 'Design your token with custom parameters, supply, and distribution model.',
  },
  {
    icon: Shield,
    title: 'Get KYC Verified',
    description: 'Complete our verification process to ensure transparency and trust.',
  },
  {
    icon: Target,
    title: 'Set Launch Parameters',
    description: 'Configure your launch details including pricing, caps, and timeline.',
  },
  {
    icon: Rocket,
    title: 'Launch Your Token',
    description: 'Go live with your token and start accepting participants.',
  },
];

export default function HowItWorks() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          How It Works
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Launch your token in four simple steps with our secure and efficient platform.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/4 right-0 w-full h-0.5 bg-gradient-to-r from-primary-500/50 to-transparent" />
              )}
              <div className="stats-card relative z-10">
                <div className="bg-primary-500/20 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6">
                  <Icon className="w-8 h-8 text-primary-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      <FeeStructure />
      <LaunchInstructions />
    </div>
  );
}
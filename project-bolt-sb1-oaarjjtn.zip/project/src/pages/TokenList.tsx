import React from 'react';
import Hero from '../components/home/Hero';
import StatsOverview from '../components/home/StatsOverview';
import Navigation from '../components/Navigation';
import TokenFilters from '../components/TokenFilters';
import TokenCard from '../components/TokenCard';
import MarketLeaderboard from '../components/leaderboard/MarketLeaderboard';
import OpportunitiesSection from '../components/opportunities/OpportunitiesSection';
import CoinGeckoChart from '../components/CoinGeckoChart';
import Partners from '../components/home/Partners';
import PremiumTokens from '../components/premium/PremiumTokens';
import BlockchainTabs from '../components/blockchain/BlockchainTabs';
import ChainPopularityMeter from '../components/blockchain/ChainPopularityMeter';
import { useBlockchainFilter } from '../hooks/useBlockchainFilter';
import { featuredTokens } from '../data/mockTokenData';

export default function TokenList() {
  const { selectedChain, filteredItems, handleChainSelect } = useBlockchainFilter(featuredTokens);

  return (
    <div>
      <Hero />
      <StatsOverview />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <Navigation />
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-8">
            <CoinGeckoChart />
            
            <div>
              <h2 className="text-2xl font-bold mb-6">Tokens</h2>
              <BlockchainTabs 
                selectedChain={selectedChain}
                onSelect={handleChainSelect}
              />
              <TokenFilters />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredItems.map((token) => (
                  <TokenCard key={token.id} {...token} />
                ))}
              </div>
            </div>

            <PremiumTokens />
            <OpportunitiesSection />
          </div>
          
          <div className="order-first lg:order-last mb-8 lg:mb-0 space-y-6">
            <MarketLeaderboard />
            <ChainPopularityMeter />
          </div>
        </div>
      </div>
      <Partners />
    </div>
  );
}
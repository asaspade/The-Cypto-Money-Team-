import React from 'react';
import { Crown, Search } from 'lucide-react';
import { usePremiumTokens } from '../hooks/usePremiumTokens';
import PremiumTokenListItem from '../components/premium/PremiumTokenListItem';

export default function PremiumTokens() {
  const { tokens, isLoading } = usePremiumTokens();

  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-yellow-600">
          Premium Tokens
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Discover high-potential tokens with verified teams and strong fundamentals
        </p>
      </div>

      <div className="flex justify-between items-center mb-8">
        <div className="relative">
          <input
            type="text"
            placeholder="Search premium tokens..."
            className="w-64 bg-gray-900/50 border border-gray-800 rounded-lg py-2 px-4 pl-10 focus:outline-none focus:border-primary-500"
          />
          <Search className="w-5 h-5 text-primary-400 absolute left-3 top-2.5" />
        </div>

        <div className="flex gap-4">
          <select className="bg-gray-900/50 border border-gray-800 rounded-lg py-2 px-4 focus:outline-none focus:border-primary-500">
            <option>Sort by: Market Cap</option>
            <option>Sort by: Volume</option>
            <option>Sort by: Price Change</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {tokens.map((token) => (
          <PremiumTokenListItem key={token.id} {...token} />
        ))}
      </div>
    </div>
  );
}
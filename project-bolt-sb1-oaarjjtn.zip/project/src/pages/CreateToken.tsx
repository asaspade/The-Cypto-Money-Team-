import React from 'react';
import { Rocket } from 'lucide-react';
import LaunchSteps from '../components/create-token/LaunchSteps';
import TokenForm from '../components/create-token/TokenForm';
import LaunchRequirements from '../components/create-token/LaunchRequirements';
import { PLATFORM_FEES } from '../config/fees';

export default function CreateToken() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <Rocket className="w-16 h-16 text-primary-500 mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Launch Your Token
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Create and launch your token with our secure, automated platform
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <TokenForm />
        </div>
        
        <div className="space-y-8">
          <LaunchRequirements />
          <LaunchSteps />
          
          <div className="stats-card">
            <h3 className="text-xl font-bold mb-4">Platform Fee</h3>
            <div className="space-y-4">
              <div className="bg-primary-500/10 p-4 rounded-lg">
                <div className="text-sm text-gray-400 mb-1">Listing Fee</div>
                <div className="text-lg font-bold">${PLATFORM_FEES.LISTING_FEE} USDC (BNB)</div>
              </div>
              <div className="bg-primary-500/10 p-4 rounded-lg">
                <div className="text-sm text-gray-400 mb-1">Transaction Fee</div>
                <div className="text-lg font-bold">{PLATFORM_FEES.TRANSACTION_FEE_PERCENT}% per trade</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Shield, CheckCircle, Clock, AlertCircle } from 'lucide-react';

export default function GetKYC() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <Shield className="w-16 h-16 text-primary-500 mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Get KYC Verified
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Complete our verification process to ensure platform security and user trust.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <div className="stats-card">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <CheckCircle className="w-6 h-6 text-primary-500" />
            Requirements
          </h2>
          <ul className="space-y-4 text-gray-400">
            <li>• Valid government-issued ID</li>
            <li>• Proof of address</li>
            <li>• Clear selfie photo</li>
            <li>• Project documentation</li>
            <li>• Team information</li>
          </ul>
        </div>

        <div className="stats-card">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Clock className="w-6 h-6 text-primary-500" />
            Process Timeline
          </h2>
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-primary-500" />
                <span className="font-semibold">Submit Documents</span>
              </div>
              <p className="text-gray-400 ml-4">1-2 hours</p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-primary-500" />
                <span className="font-semibold">Verification Review</span>
              </div>
              <p className="text-gray-400 ml-4">24-48 hours</p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-primary-500" />
                <span className="font-semibold">Final Approval</span>
              </div>
              <p className="text-gray-400 ml-4">Within 72 hours</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12 max-w-4xl mx-auto">
        <div className="stats-card">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-primary-500 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-bold mb-2">Important Notice</h3>
              <p className="text-gray-400">
                KYC verification is mandatory for all token launches on our platform. This helps us maintain
                a secure and trustworthy environment for all users. The verification process is confidential
                and handled by our certified partners.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import TokenHeader from '../components/TokenHeader';
import TokenStats from '../components/TokenStats';
import TokenProgress from '../components/TokenProgress';
import TokenActions from '../components/TokenActions';
import TokenAbout from '../components/TokenAbout';
import TokenMetrics from '../components/TokenMetrics';
import BlastOffMeter from '../components/BlastOffMeter';
import TokenTransactions from '../components/TokenTransactions';
import HolderDistribution from '../components/HolderDistribution';
import PriceChart from '../components/PriceChart';
import { tokenData } from '../data/mockTokenData';

export default function TokenDetail() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <TokenHeader
        name={tokenData.name}
        symbol={tokenData.symbol}
        address={tokenData.address}
        imageUrl={tokenData.imageUrl}
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 py-8">
        <div className="lg:col-span-2 space-y-6">
          <TokenStats
            price={tokenData.price}
            totalRaised={tokenData.totalRaised}
            participants={tokenData.participants}
            timeLeft={tokenData.timeLeft}
          />
          
          <TokenProgress
            current={tokenData.current}
            target={tokenData.target}
            percentageRaised={tokenData.percentageRaised}
          />

          <PriceChart />

          <TokenMetrics
            marketCap={tokenData.marketCap}
            totalSupply={tokenData.totalSupply}
            network={tokenData.network}
          />

          <TokenTransactions transactions={tokenData.transactions} />
          
          <HolderDistribution
            distribution={tokenData.holderDistribution.distribution}
            totalHolders={tokenData.holderDistribution.totalHolders}
          />
        </div>
        
        <div className="space-y-6">
          <TokenActions
            minContribution={tokenData.minContribution}
            maxContribution={tokenData.maxContribution}
          />
          
          <BlastOffMeter
            progress={tokenData.blastOffProgress}
            targetDate={tokenData.estimatedLaunch}
          />
          
          <TokenAbout
            description={tokenData.description}
            website={tokenData.website}
            twitter={tokenData.twitter}
            discord={tokenData.discord}
            imageUrl={tokenData.imageUrl}
          />
        </div>
      </div>
    </div>
  );
}
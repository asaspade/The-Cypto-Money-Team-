import React from 'react';
import { ArrowDownUp } from 'lucide-react';
import SwapperTabs from '../components/swapper/SwapperTabs';
import SwapperStats from '../components/swapper/SwapperStats';

export default function Swapper() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <ArrowDownUp className="w-16 h-16 text-primary-500 mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
          Vitruveo Swapper
        </h1>
        <p className="text-xl text-gray-400">
          Bridge, swap, and wrap your tokens seamlessly
        </p>
      </div>

      <div className="space-y-8">
        <SwapperStats />
        <SwapperTabs />
      </div>
    </div>
  );
}
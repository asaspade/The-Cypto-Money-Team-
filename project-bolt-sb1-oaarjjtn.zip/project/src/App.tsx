import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AdminProvider } from './contexts/AdminContext';
import { WalletProvider } from './contexts/WalletContext';
import Layout from './components/Layout';
import TokenList from './pages/TokenList';
import TokenDetail from './pages/TokenDetail';
import Following from './pages/Following';
import MyCoins from './pages/MyCoins';
import Static from './pages/Static';
import Live from './pages/Live';
import CreateToken from './pages/CreateToken';
import HowItWorks from './pages/HowItWorks';
import GetKYC from './pages/GetKYC';
import AboutUs from './pages/AboutUs';
import Roadmap from './pages/Roadmap';
import Swapper from './pages/Swapper';
import PremiumTokens from './pages/PremiumTokens';

export default function App() {
  return (
    <AdminProvider>
      <WalletProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<TokenList />} />
              <Route path="/following" element={<Following />} />
              <Route path="/my-coins" element={<MyCoins />} />
              <Route path="/static" element={<Static />} />
              <Route path="/live" element={<Live />} />
              <Route path="/token/:id" element={<TokenDetail />} />
              <Route path="/token/launch" element={<CreateToken />} />
              <Route path="/how-it-works" element={<HowItWorks />} />
              <Route path="/get-kyc" element={<GetKYC />} />
              <Route path="/about" element={<AboutUs />} />
              <Route path="/roadmap" element={<Roadmap />} />
              <Route path="/swapper" element={<Swapper />} />
              <Route path="/premium-tokens" element={<PremiumTokens />} />
            </Route>
          </Routes>
        </Router>
      </WalletProvider>
    </AdminProvider>
  );
}
import { TokenInfo } from '../types/token';
import { premiumTokens } from '../data/premiumTokens';

const VITRUVEO_EXPLORER_URL = 'https://explorer.vitruveo.xyz';
const FALLBACK_DELAY = 1000; // Simulate network delay for fallback data

export async function fetchTopTokens(): Promise<TokenInfo[]> {
  try {
    const response = await fetch(`${VITRUVEO_EXPLORER_URL}/api/tokens`);
    if (!response.ok) throw new Error('Failed to fetch token data');
    
    const data = await response.json();
    return data.map((token: any) => ({
      id: token.address,
      name: token.name,
      symbol: token.symbol,
      price: formatPrice(token.price),
      change: formatChange(token.priceChange24h),
      isPositive: token.priceChange24h >= 0,
      marketCap: formatMarketCap(token.marketCap),
      volume24h: formatVolume(token.volume24h)
    }));
  } catch (error) {
    // Return mock data after a small delay to prevent UI flashing
    await new Promise(resolve => setTimeout(resolve, FALLBACK_DELAY));
    
    return premiumTokens.map(token => ({
      ...token,
      marketCap: generateRandomMarketCap(),
      volume24h: generateRandomVolume()
    }));
  }
}

function formatPrice(price: number): string {
  return price < 0.01 
    ? `$${price.toFixed(8)}`
    : `$${price.toFixed(4)}`;
}

function formatChange(change: number): string {
  return `${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
}

function formatMarketCap(marketCap: number): string {
  if (marketCap >= 1e9) return `$${(marketCap / 1e9).toFixed(2)}B`;
  if (marketCap >= 1e6) return `$${(marketCap / 1e6).toFixed(2)}M`;
  return `$${(marketCap / 1e3).toFixed(2)}K`;
}

function formatVolume(volume: number): string {
  if (volume >= 1e9) return `$${(volume / 1e9).toFixed(2)}B`;
  if (volume >= 1e6) return `$${(volume / 1e6).toFixed(2)}M`;
  return `$${(volume / 1e3).toFixed(2)}K`;
}

// Helper functions to generate realistic-looking random data
function generateRandomMarketCap(): string {
  const base = Math.random() * 100 + 10; // Random number between 10 and 110
  return `$${base.toFixed(2)}M`;
}

function generateRandomVolume(): string {
  const base = Math.random() * 10 + 1; // Random number between 1 and 11
  return `$${base.toFixed(2)}M`;
}
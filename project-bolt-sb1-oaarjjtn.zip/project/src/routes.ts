export const routes = {
  home: '/',
  tokenDetail: (id: string) => `/token/${id}`,
} as const;